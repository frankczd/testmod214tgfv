package com.example.isekai;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Client-side species table. No Minecraft client imports. */
public final class ClientSpecies {
    private static Map<String, SpeciesListPayload.Entry> map = new LinkedHashMap<>();
    private ClientSpecies() {}

    public static void set(List<SpeciesListPayload.Entry> entries) {
        Map<String, SpeciesListPayload.Entry> m = new LinkedHashMap<>();
        entries.forEach(e -> m.put(e.id(), e));
        map = m;
    }

    /** Null if id is empty or unknown. */
    public static SpeciesListPayload.Entry get(String id) { return map.get(id); }

    public static List<SpeciesListPayload.Entry> startOptions() {
        List<SpeciesListPayload.Entry> out = new ArrayList<>();
        for (SpeciesListPayload.Entry e : map.values()) if (e.start()) out.add(e);
        return out;
    }
}
