package com.example.isekai;

/** Client-side copy of the local player's stats. No Minecraft client imports. */
public final class ClientStats {
    private static PlayerStats stats = PlayerStats.DEFAULT;
    private static int[] totals = new int[5];
    private static int maxMp = 52;
    private ClientStats() {}
    public static PlayerStats get() { return stats; }
    public static int[] totals() { return totals; }
    public static int maxMp() { return maxMp; }
    public static void set(PlayerStats s, int[] t, int m) { stats = s; totals = t; maxMp = m; }
}
