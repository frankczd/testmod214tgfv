package com.example.isekai.client;

import com.example.isekai.ClientSpecies;
import com.example.isekai.ClientStats;
import com.example.isekai.PlayerStats;
import com.example.isekai.SkillListPayload;
import com.example.isekai.SpeciesListPayload.Entry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

/** Small top-left readout: species, level, MP bar, XP bar. */
public class HudOverlay {
    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || mc.screen instanceof StatusScreen) return;
        PlayerStats s = ClientStats.get();
        if (s.species().isEmpty()) return;
        Entry sp = ClientSpecies.get(s.species());
        int x = 6, y = 6, w = 90, max = ClientStats.maxMp();
        g.drawString(mc.font, (sp != null ? sp.name() : s.species()) + "  Lv " + s.level(), x, y, 0xFFFFFF);
        StatusScreen.bar(g, x, y + 12, w, 7, s.mp() / (float) max, 0xFF3A7BFF);
        g.drawString(mc.font, "MP " + s.mp() + "/" + max, x + w + 4, y + 11, 0xA0C0FF);
        StatusScreen.bar(g, x, y + 22, w, 3, s.xp() / (float) s.xpToNext(), 0xFFE0B030);
        SkillListPayload.Entry sel = ClientCasting.selected();
        if (sel != null) {
            g.drawString(mc.font, "> " + sel.name() + " (" + sel.castMp() + " MP)  [R] cast  [V/B] switch",
                    x, y + 30, 0xFFD060);
        }
    }
}
