package com.example.isekai;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads skill JSON from data packs. Registered in StatsEvents. */
public class SkillDefs extends SimpleJsonResourceReloadListener {
    public static final SkillDefs INSTANCE = new SkillDefs();
    private static Map<String, Skill> skills = new LinkedHashMap<>();

    private SkillDefs() { super(new Gson(), "skills"); }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> files, ResourceManager rm, ProfilerFiller profiler) {
        Map<String, Skill> loaded = new LinkedHashMap<>();
        files.forEach((id, json) -> Skill.CODEC.parse(JsonOps.INSTANCE, json)
                .resultOrPartial(err -> System.err.println("[isekai] bad skill " + id + ": " + err))
                .ifPresent(s -> loaded.put(id.getPath(), s)));
        skills = loaded;
    }

    public static Skill get(String id) { return skills.get(id); }

    public static Map<String, Skill> all() { return skills; }

    public static SkillListPayload listPayload() {
        List<SkillListPayload.Entry> out = new ArrayList<>();
        skills.forEach((id, s) -> out.add(new SkillListPayload.Entry(
                id, s.name(), s.description(), s.tier(), s.maxLevel(), s.cost(), s.learnAmount(),
                s.fx().cast().castable() ? s.fx().cast().mp() : -1, s.evolvesTo())));
        return new SkillListPayload(out);
    }
}
