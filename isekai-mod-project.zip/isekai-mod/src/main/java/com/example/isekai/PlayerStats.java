package com.example.isekai;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.FriendlyByteBuf;

/** Immutable RPG data. Allocated stat fields are points YOU spent; species base/growth are added on top. */
public record PlayerStats(int level, int xp, int points,
                          int offense, int defense, int magic, int resistance, int speed,
                          int mp, String species, int skillPoints) {

    public static final String[] STAT_NAMES = {"Offense", "Defense", "Magic", "Resistance", "Speed"};
    public static final int POINTS_PER_LEVEL = 3;
    /** Minecraft max health = canon HP * HP_SCALE. 1.0 means canon HP is your real HP (1 heart = 2 HP). */
    public static final double HP_SCALE = 1.0;
    public static final PlayerStats DEFAULT = new PlayerStats(1, 0, 0, 0, 0, 0, 0, 0, 52, "", 0);

    public static final Codec<PlayerStats> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.optionalFieldOf("level", 1).forGetter(PlayerStats::level),
            Codec.INT.optionalFieldOf("xp", 0).forGetter(PlayerStats::xp),
            Codec.INT.optionalFieldOf("points", 0).forGetter(PlayerStats::points),
            Codec.INT.optionalFieldOf("offense", 0).forGetter(PlayerStats::offense),
            Codec.INT.optionalFieldOf("defense", 0).forGetter(PlayerStats::defense),
            Codec.INT.optionalFieldOf("magic", 0).forGetter(PlayerStats::magic),
            Codec.INT.optionalFieldOf("resistance", 0).forGetter(PlayerStats::resistance),
            Codec.INT.optionalFieldOf("speed", 0).forGetter(PlayerStats::speed),
            Codec.INT.optionalFieldOf("mp", 52).forGetter(PlayerStats::mp),
            Codec.STRING.optionalFieldOf("species", "").forGetter(PlayerStats::species),
            Codec.INT.optionalFieldOf("skill_points", 0).forGetter(PlayerStats::skillPoints)
    ).apply(i, PlayerStats::new));

    public int stat(int i) {
        return switch (i) {
            case 0 -> offense;
            case 1 -> defense;
            case 2 -> magic;
            case 3 -> resistance;
            case 4 -> speed;
            default -> 0;
        };
    }

    public static int xpNeeded(int level) { return 40 + level * 20 + level * level; }
    public int xpToNext() { return xpNeeded(level); }

    private PlayerStats lxp(int l, int x, int p, int sk) {
        return new PlayerStats(l, x, p, offense, defense, magic, resistance, speed, mp, species, sk);
    }

    /** Spend one point on stat i. Returns this (same instance) if not allowed. */
    public PlayerStats spend(int i) {
        if (points <= 0 || i < 0 || i > 4) return this;
        return new PlayerStats(level, xp, points - 1,
                i == 0 ? offense + 1 : offense, i == 1 ? defense + 1 : defense, i == 2 ? magic + 1 : magic,
                i == 3 ? resistance + 1 : resistance, i == 4 ? speed + 1 : speed, mp, species, skillPoints);
    }

    public PlayerStats withMp(int v) {
        return new PlayerStats(level, xp, points, offense, defense, magic, resistance, speed,
                Math.max(0, v), species, skillPoints);
    }

    /** Choosing a start or evolving: new species, level back to 1 (canon), spent points are kept. */
    public PlayerStats withSpecies(String id) {
        return new PlayerStats(1, 0, points, offense, defense, magic, resistance, speed, mp, id, skillPoints);
    }

    public PlayerStats addSkillPoints(int n) {
        return new PlayerStats(level, xp, points, offense, defense, magic, resistance, speed, mp, species, skillPoints + n);
    }

    /** skillPointsPerLevel comes from the species (humans get a bonus). */
    public PlayerStats addXp(int amount, int maxLevel, int skillPointsPerLevel) {
        int lvl = level, x = xp + amount, p = points, sk = skillPoints;
        while (lvl < maxLevel && x >= xpNeeded(lvl)) {
            x -= xpNeeded(lvl);
            lvl++;
            p += POINTS_PER_LEVEL;
            sk += skillPointsPerLevel;
        }
        if (lvl >= maxLevel) x = 0;
        return lxp(lvl, x, p, sk);
    }

    public void write(FriendlyByteBuf b) {
        b.writeVarInt(level); b.writeVarInt(xp); b.writeVarInt(points);
        b.writeVarInt(offense); b.writeVarInt(defense); b.writeVarInt(magic);
        b.writeVarInt(resistance); b.writeVarInt(speed); b.writeVarInt(mp);
        b.writeUtf(species);
        b.writeVarInt(skillPoints);
    }

    public static PlayerStats read(FriendlyByteBuf b) {
        return new PlayerStats(b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(),
                b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readUtf(), b.readVarInt());
    }
}
