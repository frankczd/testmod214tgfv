package com.example.isekai;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

/** One owned skill: its level and progress toward the next level. */
public record SkillState(int level, int xp) {
    public static final Codec<SkillState> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.optionalFieldOf("level", 1).forGetter(SkillState::level),
            Codec.INT.optionalFieldOf("xp", 0).forGetter(SkillState::xp)
    ).apply(i, SkillState::new));
}
