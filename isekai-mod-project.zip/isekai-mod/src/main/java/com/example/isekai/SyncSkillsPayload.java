package com.example.isekai;

import io.netty.buffer.ByteBuf;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: the player's owned skills. */
public record SyncSkillsPayload(Map<String, SkillState> skills) implements CustomPacketPayload {
    public static final Type<SyncSkillsPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "sync_skills"));

    public static final StreamCodec<ByteBuf, SyncSkillsPayload> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeInt(p.skills().size());
                p.skills().forEach((id, st) -> {
                    ByteBufCodecs.STRING_UTF8.encode(buf, id);
                    buf.writeInt(st.level());
                    buf.writeInt(st.xp());
                });
            },
            buf -> {
                int n = buf.readInt();
                Map<String, SkillState> m = new LinkedHashMap<>();
                for (int i = 0; i < n; i++) {
                    String id = ByteBufCodecs.STRING_UTF8.decode(buf);
                    m.put(id, new SkillState(buf.readInt(), buf.readInt()));
                }
                return new SyncSkillsPayload(m);
            });

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
