package com.example.isekai;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.AddReloadListenerEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = IsekaiMod.MODID)
public class StatsEvents {

    private static void resync(Player player) {
        if (player instanceof ServerPlayer sp) {
            StatsManager.fullSync(sp);
            SkillManager.sync(sp);
        }
    }

    @SubscribeEvent
    public static void onReload(AddReloadListenerEvent e) {
        e.addListener(SpeciesManager.INSTANCE);
        e.addListener(SkillDefs.INSTANCE);
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) {
            PacketDistributor.sendToPlayer(sp, SpeciesListPayload.fromManager()); // before stats, so the picker has data
            PacketDistributor.sendToPlayer(sp, SkillDefs.listPayload());
        }
        resync(e.getEntity());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) { resync(e.getEntity()); }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) { resync(e.getEntity()); }

    /** XP for kills, scaled by the victim's max health. */
    @SubscribeEvent
    public static void onKill(LivingDeathEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer sp && !(e.getEntity() instanceof Player)) {
            StatsManager.giveXp(sp, Math.max(1, (int) (e.getEntity().getMaxHealth() / 2)));
        }
    }

    /** Before damage lands: attack/enhancement skills add damage, resistance skills absorb it. */
    @SubscribeEvent
    public static void onIncoming(LivingIncomingDamageEvent e) {
        LivingEntity victim = e.getEntity();
        if (e.getSource().getEntity() instanceof ServerPlayer a && a != victim && e.getSource().getDirectEntity() == a) {
            double bonus = SkillManager.meleeBonus(a);
            ItemStack held = a.getMainHandItem();
            if (held.is(ItemTags.SWORDS)) bonus += SkillManager.passiveTotal(a, "sword");
            else if (held.isEmpty()) bonus += SkillManager.passiveTotal(a, "unarmed");
            if (bonus > 0) e.setAmount((float) (e.getAmount() + bonus));
        }
        if (victim instanceof ServerPlayer v) {
            double dodge = Math.min(50, SkillManager.passiveTotal(v, "dodge")); // Prediction / Foresight
            if (dodge > 0 && v.getRandom().nextDouble() * 100 < dodge) {
                v.displayClientMessage(Component.literal("Dodged!"), true);
                e.setCanceled(true);
                return;
            }
            String cat = SkillManager.category(e.getSource());
            double pct = cat.isEmpty() ? 0 : SkillManager.resistPct(v, cat);
            if (pct > 0) {
                float left = (float) (e.getAmount() * (1.0 - pct / 100.0));
                e.setAmount(left);
                if (left <= 0) e.setCanceled(true);
            }
        }
    }

    /** After damage lands: skill training, learning, Poison Fang and on-hit effects. */
    @SubscribeEvent
    public static void onDamage(LivingDamageEvent.Post e) {
        LivingEntity victim = e.getEntity();
        if (victim instanceof ServerPlayer v) {
            SkillManager.train(v, "take_damage", 1);
            String cat = SkillManager.category(e.getSource());
            if (!cat.isEmpty()) SkillManager.train(v, "dmg_" + cat, 1); // learn/level resistances by exposure
        }
        if (e.getSource().getEntity() instanceof ServerPlayer attacker && attacker != victim) {
            if (e.getSource().getDirectEntity() != null) SkillManager.train(attacker, "deal_damage", 1); // not for spells
            if (e.getSource().getDirectEntity() == attacker) {
                SkillManager.onMelee(attacker, victim);
                double leech = SkillManager.passiveTotal(attacker, "vampire");
                if (leech > 0) attacker.heal((float) (e.getNewDamage() * leech / 100.0));
            }
        }
    }

    /** Once per second: MP regen, HP recovery skills, sprint training. Skills re-sync every 5 seconds. */
    @SubscribeEvent
    public static void onTick(PlayerTickEvent.Post e) {
        if (!(e.getEntity() instanceof ServerPlayer sp) || sp.tickCount % 20 != 0) return;
        PlayerStats s = StatsManager.get(sp);
        if (s.species().isEmpty()) return;

        int max = StatsManager.maxMp(sp, s);
        if (s.mp() < max) {
            double pct = SkillManager.regenPct(sp, false);
            int gain = (int) Math.round(1 + max / 50.0 + max * pct / 100.0);
            StatsManager.save(sp, s.withMp(Math.min(max, s.mp() + gain)));
            SkillManager.train(sp, "mp_recover", 1);
        }

        if (sp.getHealth() < sp.getMaxHealth()) SkillManager.train(sp, "wounded", 1); // lets you learn HP Auto-Recovery
        double hpPct = SkillManager.regenPct(sp, true);
        if (hpPct > 0 && sp.getHealth() < sp.getMaxHealth()) {
            sp.heal((float) (sp.getMaxHealth() * hpPct / 100.0));
            SkillManager.train(sp, "recover", 1);
        }

        SkillManager.passiveTick(sp);
        if (sp.isSprinting()) SkillManager.train(sp, "sprint", 1);
        if (sp.tickCount % 100 == 0) {
            SkillManager.train(sp, "alive", 1); // passive skills level slowly just by being owned
            SkillManager.sync(sp);
        }
    }

    /** Debug (op): /isekai addxp <n>, addsp <n>, grantskill <id> <level>, setspecies <id>, reset */
    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("isekai")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("addxp")
                        .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                .executes(ctx -> {
                                    StatsManager.giveXp(ctx.getSource().getPlayerOrException(),
                                            IntegerArgumentType.getInteger(ctx, "amount"));
                                    return 1;
                                })))
                .then(Commands.literal("addsp")
                        .then(Commands.argument("amount", IntegerArgumentType.integer(1))
                                .executes(ctx -> {
                                    ServerPlayer sp = ctx.getSource().getPlayerOrException();
                                    StatsManager.save(sp, StatsManager.get(sp)
                                            .addSkillPoints(IntegerArgumentType.getInteger(ctx, "amount")));
                                    return 1;
                                })))
                .then(Commands.literal("grantskill")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .then(Commands.argument("level", IntegerArgumentType.integer(1))
                                        .executes(ctx -> {
                                            ServerPlayer sp = ctx.getSource().getPlayerOrException();
                                            SkillManager.grant(sp, StringArgumentType.getString(ctx, "id"),
                                                    IntegerArgumentType.getInteger(ctx, "level"));
                                            StatsManager.fullSync(sp);
                                            SkillManager.sync(sp);
                                            return 1;
                                        }))))
                .then(Commands.literal("setspecies")
                        .then(Commands.argument("id", StringArgumentType.word())
                                .executes(ctx -> {
                                    ServerPlayer sp = ctx.getSource().getPlayerOrException();
                                    String id = StringArgumentType.getString(ctx, "id");
                                    Species target = SpeciesManager.get(id);
                                    if (target == null) return 0;
                                    SkillManager.applySpeciesSkills(sp, target);
                                    PlayerStats n = StatsManager.get(sp).withSpecies(id);
                                    StatsManager.save(sp, n.withMp(StatsManager.maxMp(sp, n)));
                                    StatsManager.refresh(sp);
                                    SkillManager.sync(sp);
                                    return 1;
                                })))
                .then(Commands.literal("reset").executes(ctx -> {
                    ServerPlayer sp = ctx.getSource().getPlayerOrException();
                    sp.setData(ModAttachments.STATS, PlayerStats.DEFAULT);
                    sp.setData(ModAttachments.SKILLS, PlayerSkills.EMPTY);
                    StatsManager.fullSync(sp);
                    SkillManager.sync(sp);
                    return 1;
                })));
    }
}
