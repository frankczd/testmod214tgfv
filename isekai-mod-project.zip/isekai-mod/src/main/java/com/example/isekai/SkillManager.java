package com.example.isekai;

import java.util.ArrayList;
import java.util.Map;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Abilities;
import net.neoforged.neoforge.network.PacketDistributor;

/** Server-side skill logic: learning by doing, buying, use-based leveling, evolution, and stat bonuses. */
public final class SkillManager {
    private SkillManager() {}

    public static PlayerSkills get(Player p) { return p.getData(ModAttachments.SKILLS); }
    private static void set(ServerPlayer p, PlayerSkills s) { p.setData(ModAttachments.SKILLS, s); }

    public static void sync(ServerPlayer p) {
        PacketDistributor.sendToPlayer(p, new SyncSkillsPayload(get(p).map()));
    }

    /** Raise a skill to at least this level (adds it if missing). Ignores unknown skill ids. */
    public static void grant(ServerPlayer p, String id, int level) {
        Skill d = SkillDefs.get(id);
        if (d == null) return;
        int lv = Math.max(1, Math.min(d.maxLevel(), level));
        PlayerSkills sk = get(p);
        SkillState cur = sk.get(id);
        if (cur == null || cur.level() < lv) set(p, sk.with(id, new SkillState(lv, 0)));
    }

    /** Species skill lists look like ["poison_fang:4", "night_vision:10"]. */
    public static void applySpeciesSkills(ServerPlayer p, Species s) {
        for (String entry : s.skills()) {
            String[] a = entry.split(":");
            int lv = 1;
            try { if (a.length > 1) lv = Integer.parseInt(a[1]); } catch (NumberFormatException ignored) {}
            grant(p, a[0], lv);
        }
    }

    /** Stat bonus from skills: flat per skill level plus growth for every character level past 1. */
    public static double statBonus(Player p, int charLevel, int statIdx) {
        double sum = 0;
        for (Map.Entry<String, SkillState> e : get(p).map().entrySet()) {
            Skill d = SkillDefs.get(e.getKey());
            if (d == null) continue;
            int idx = d.statIndex();
            boolean physical = idx == 8 && (statIdx == 0 || statIdx == 1 || statIdx == 4);
            if (idx != statIdx && !(idx == 7 && statIdx < 5) && !physical) continue; // 7 = all, 8 = physical
            int lv = e.getValue().level();
            sum += lv * d.flatPerLevel() + (charLevel - 1) * lv * d.growthPerLevel();
        }
        return sum;
    }

    /** Percent of max HP (or MP) recovered per second from recovery skills. */
    public static double regenPct(Player p, boolean hp) {
        double sum = 0;
        for (Map.Entry<String, SkillState> e : get(p).map().entrySet()) {
            Skill d = SkillDefs.get(e.getKey());
            if (d != null) sum += e.getValue().level() * (hp ? d.hpRegenPct() : d.mpRegenPct());
        }
        return sum;
    }

    /**
     * Call with an action name ("deal_damage", "sprint", ...).
     * 1) Skills you own that train on it gain XP, level up, and evolve at max level.
     * 2) Skills you don't own yet that are learned by it gain progress and unlock when the goal is hit.
     */
    public static void train(ServerPlayer p, String trigger, int amount) {
        double boost = passiveTotal(p, "skill_xp") / 100.0; // Memory / Record
        if (boost > 0) {
            double v = amount * (1 + boost);
            amount = (int) Math.floor(v) + (java.util.concurrent.ThreadLocalRandom.current().nextDouble() < v - Math.floor(v) ? 1 : 0);
            if (amount <= 0) return;
        }
        PlayerSkills start = get(p);
        PlayerSkills cur = start;
        boolean statsChanged = false;

        for (Map.Entry<String, SkillState> e : new ArrayList<>(start.map().entrySet())) {
            if (e.getValue().level() < 1) continue; // learning progress, not owned
            Skill d = SkillDefs.get(e.getKey());
            if (d == null || !trigger.equals(d.trainOn())) continue;
            String id = e.getKey();
            int lv = e.getValue().level();
            int xp = e.getValue().xp() + amount * d.trainXp();
            if (lv >= d.maxLevel() && d.evolvesTo().isEmpty()) continue;
            while (lv < d.maxLevel() && xp >= Skill.xpNeeded(lv, d.tier())) {
                xp -= Skill.xpNeeded(lv, d.tier());
                lv++;
                statsChanged = true;
                p.displayClientMessage(Component.literal(d.name() + " reached Lv " + lv), true);
            }
            if (lv >= d.maxLevel() && !d.evolvesTo().isEmpty()) {
                String next = d.evolvesTo().get(0);
                Skill nd = SkillDefs.get(next);
                if (nd != null) {
                    cur = cur.without(id).with(next, new SkillState(1, 0));
                    p.sendSystemMessage(Component.literal(d.name() + " evolved into " + nd.name() + "!"));
                    statsChanged = true;
                    continue;
                }
            }
            cur = cur.with(id, new SkillState(lv, lv >= d.maxLevel() ? 0 : xp));
        }

        for (Map.Entry<String, Skill> e : SkillDefs.all().entrySet()) {
            Skill d = e.getValue();
            if (d.learnAmount() <= 0 || !trigger.equals(d.learnOn())) continue;
            String id = e.getKey();
            if (cur.owns(id) || ownsDescendant(cur, id)) continue;
            SkillState st = cur.get(id);
            int progress = (st == null ? 0 : st.xp()) + amount;
            if (progress >= d.learnAmount()) {
                cur = cur.with(id, new SkillState(1, 0));
                p.sendSystemMessage(Component.literal("You learned " + d.name() + "!"));
                statsChanged = true;
            } else {
                cur = cur.with(id, new SkillState(0, progress));
            }
        }

        if (cur != start) {
            set(p, cur);
            if (statsChanged) {
                StatsManager.fullSync(p); // stat bonuses changed
                sync(p);
            }
        }
    }

    private static boolean ownsDescendant(PlayerSkills sk, String id) {
        Skill d = SkillDefs.get(id);
        if (d == null) return false;
        for (String n : d.evolvesTo()) if (sk.owns(n) || ownsDescendant(sk, n)) return true;
        return false;
    }

    public static void buy(ServerPlayer p, String id) {
        Skill d = SkillDefs.get(id);
        PlayerSkills sk = get(p);
        PlayerStats s = StatsManager.get(p);
        if (d == null || d.cost() <= 0 || sk.owns(id) || ownsDescendant(sk, id)) return;
        if (s.skillPoints() < d.cost()) return;
        p.setData(ModAttachments.STATS, s.addSkillPoints(-d.cost()));
        set(p, sk.with(id, new SkillState(1, 0)));
        StatsManager.fullSync(p);
        sync(p);
        p.sendSystemMessage(Component.literal("Learned " + d.name() + " (-" + d.cost() + " skill points)"));
    }

    /** Called when a player lands a melee hit: Poison Fang, on-hit skills, and "melee_hit" training. */
    public static void onMelee(ServerPlayer attacker, LivingEntity victim) {
        SkillState fang = get(attacker).get("poison_fang");
        if (fang != null && fang.level() >= 1) {
            int lv = fang.level();
            victim.addEffect(new MobEffectInstance(MobEffects.POISON, (3 + lv) * 20, lv >= 7 ? 1 : 0), attacker);
            train(attacker, "poison_fang_hit", 1);
        }
        applyHitEffects(attacker, victim);
        train(attacker, "melee_hit", 1);
    }

    /** Extra damage added to melee hits by attack/enhancement skills. */
    public static double meleeBonus(Player p) {
        double sum = 0;
        for (Map.Entry<String, SkillState> e : get(p).map().entrySet()) {
            Skill d = SkillDefs.get(e.getKey());
            if (d != null) sum += e.getValue().level() * d.fx().hitDamage();
        }
        return sum;
    }

    /** Status effects from attack skills (fire, poison, freeze, ...). Lasts seconds-per-level x level. */
    public static void applyHitEffects(ServerPlayer attacker, LivingEntity victim) {
        for (Map.Entry<String, SkillState> e : get(attacker).map().entrySet()) {
            Skill d = SkillDefs.get(e.getKey());
            if (d == null || d.fx().hitEffect().isEmpty() || e.getValue().level() < 1) continue;
            int ticks = (int) Math.round(d.fx().hitSeconds() * e.getValue().level() * 20);
            if (ticks <= 0) continue;
            switch (d.fx().hitEffect()) {
                case "fire" -> victim.setRemainingFireTicks(Math.max(victim.getRemainingFireTicks(), ticks));
                case "freeze" -> victim.setTicksFrozen(victim.getTicksFrozen() + ticks);
                case "poison" -> victim.addEffect(new MobEffectInstance(MobEffects.POISON, ticks, 0), attacker);
                case "slowness" -> victim.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 1), attacker);
                case "weakness" -> victim.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 0), attacker);
                case "wither" -> victim.addEffect(new MobEffectInstance(MobEffects.WITHER, ticks, 0), attacker);
                default -> { }
            }
        }
    }

    /** Percent of this kind of damage your resistance skills absorb (capped at 100). */
    public static double resistPct(Player p, String category) {
        double sum = 0;
        for (Map.Entry<String, SkillState> e : get(p).map().entrySet()) {
            Skill d = SkillDefs.get(e.getKey());
            if (d != null && d.fx().resist().contains(category)) sum += e.getValue().level() * d.fx().resistPct();
        }
        return Math.min(100, sum);
    }

    /** Sum of skill level x passive_power for every owned skill with this passive. */
    public static double passiveTotal(Player p, String passive) {
        double sum = 0;
        for (Map.Entry<String, SkillState> e : get(p).map().entrySet()) {
            Skill d = SkillDefs.get(e.getKey());
            if (d != null && e.getValue().level() >= 1 && passive.equals(d.fx().passive())) {
                sum += e.getValue().level() * d.fx().passivePower();
            }
        }
        return sum;
    }

    /** Permanent effects from passive skills. Called once per second. */
    public static void passiveTick(ServerPlayer p) {
        boolean fly = false;
        int flyTier = 1;
        for (Map.Entry<String, SkillState> e : get(p).map().entrySet()) {
            Skill d = SkillDefs.get(e.getKey());
            if (d == null || e.getValue().level() < 1 || d.fx().passive().isEmpty()) continue;
            int lv = e.getValue().level();
            switch (d.fx().passive()) {
                case "night_vision" -> p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, true, false, false));
                case "flight" -> { fly = true; flyTier = Math.max(flyTier, d.tier()); }
                case "camouflage" -> {
                    boolean still = p.getDeltaMovement().horizontalDistanceSqr() < 1.0E-4;
                    if (p.isShiftKeyDown() || (d.tier() >= 2 && still)) {
                        p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 40, 0, true, false, false));
                    }
                }
                case "swim" -> {
                    if (p.isInWater()) p.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 40, d.tier() - 1, true, false, false));
                }
                case "intimidate" -> {
                    double r = (4 + lv) * Math.max(1.0, d.fx().passivePower());
                    for (Monster m : p.level().getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(r), Monster::isAlive)) {
                        m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 0));
                        if (d.tier() >= 2) m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, d.tier() - 2));
                    }
                }
                default -> { }
            }
        }
        flightTick(p, fly, flyTier);
    }

    /** Survival flight that costs MP while you are airborne. */
    private static void flightTick(ServerPlayer p, boolean has, int tier) {
        if (p.isCreative() || p.isSpectator()) return;
        Abilities ab = p.getAbilities();
        PlayerStats s = StatsManager.get(p);
        boolean allowed = has && s.mp() > 0;
        if (allowed && !ab.mayfly) {
            ab.mayfly = true;
            p.onUpdateAbilities();
        } else if (!allowed && ab.mayfly) {
            ab.mayfly = false;
            ab.flying = false;
            p.onUpdateAbilities();
        }
        if (allowed && ab.flying) {
            StatsManager.save(p, s.withMp(Math.max(0, s.mp() - (tier >= 2 ? 1 : 3))));
        }
    }

    /** Groups Minecraft damage types into the categories resistance skills use. */
    public static String category(DamageSource src) {
        String key = src.typeHolder().unwrapKey().map(k -> k.location().getPath()).orElse("");
        return switch (key) {
            case "in_fire", "on_fire", "lava", "hot_floor", "fireball", "unattributed_fireball", "campfire" -> "fire";
            case "magic", "indirect_magic" -> "magic";
            case "wither", "wither_skull" -> "wither";
            case "drown" -> "drown";
            case "freeze" -> "freeze";
            case "lightning_bolt" -> "lightning";
            case "fall", "fly_into_wall", "falling_block", "falling_anvil" -> "impact";
            case "arrow", "trident", "mob_projectile", "thrown", "stalagmite", "falling_stalactite", "cactus" -> "projectile";
            case "explosion", "player_explosion" -> "blast";
            case "player_attack", "mob_attack", "mob_attack_no_aggro", "sting" -> "physical";
            case "in_wall", "cramming", "sweet_berry_bush" -> "earth";
            default -> "";
        };
    }
}
