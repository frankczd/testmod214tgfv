package com.example.isekai;

import com.mojang.serialization.Codec;
import java.util.LinkedHashMap;
import java.util.Map;

/** Every skill a player owns, by skill id. Immutable. */
public record PlayerSkills(Map<String, SkillState> map) {
    public static final PlayerSkills EMPTY = new PlayerSkills(Map.of());
    public static final Codec<PlayerSkills> CODEC =
            Codec.unboundedMap(Codec.STRING, SkillState.CODEC).xmap(PlayerSkills::new, PlayerSkills::map);

    public SkillState get(String id) { return map.get(id); }

    /** Level 0 entries are just learning progress, not an owned skill. */
    public boolean owns(String id) {
        SkillState st = map.get(id);
        return st != null && st.level() >= 1;
    }

    public PlayerSkills with(String id, SkillState s) {
        Map<String, SkillState> m = new LinkedHashMap<>(map);
        m.put(id, s);
        return new PlayerSkills(m);
    }

    public PlayerSkills without(String id) {
        Map<String, SkillState> m = new LinkedHashMap<>(map);
        m.remove(id);
        return new PlayerSkills(m);
    }
}
