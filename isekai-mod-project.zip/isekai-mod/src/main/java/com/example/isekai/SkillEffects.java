package com.example.isekai;

import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.phys.Vec3;

/** Applies named effects ("fire", "stun", "regeneration"...) to targets or to the caster. */
public final class SkillEffects {
    private SkillEffects() {}

    private static Holder<MobEffect> potion(String n) {
        return switch (n) {
            case "poison" -> MobEffects.POISON;
            case "slowness" -> MobEffects.MOVEMENT_SLOWDOWN;
            case "weakness" -> MobEffects.WEAKNESS;
            case "wither" -> MobEffects.WITHER;
            case "blind" -> MobEffects.BLINDNESS;
            case "nausea" -> MobEffects.CONFUSION;
            case "darkness" -> MobEffects.DARKNESS;
            case "glow" -> MobEffects.GLOWING;
            case "levitate" -> MobEffects.LEVITATION;
            case "fatigue" -> MobEffects.DIG_SLOWDOWN;
            case "regeneration" -> MobEffects.REGENERATION;
            case "resistance" -> MobEffects.DAMAGE_RESISTANCE;
            case "strength" -> MobEffects.DAMAGE_BOOST;
            case "speed" -> MobEffects.MOVEMENT_SPEED;
            case "absorption" -> MobEffects.ABSORPTION;
            case "haste" -> MobEffects.DIG_SPEED;
            case "fire_resistance" -> MobEffects.FIRE_RESISTANCE;
            case "invisibility" -> MobEffects.INVISIBILITY;
            default -> null;
        };
    }

    /** Effects on something you hit or aimed at. effect can be comma separated. */
    public static void apply(ServerPlayer caster, LivingEntity t, String effect, int ticks, int amp) {
        for (String n : effect.split(",")) one(caster, t, n.trim(), Math.max(20, ticks), amp);
    }

    /** Effects on yourself. */
    public static void self(ServerPlayer p, String effect, int ticks, int amp) {
        for (String n : effect.split(",")) {
            Holder<MobEffect> h = potion(n.trim());
            if (h != null) p.addEffect(new MobEffectInstance(h, Math.max(20, ticks), amp));
        }
    }

    private static void one(ServerPlayer caster, LivingEntity t, String n, int ticks, int amp) {
        Vec3 away = t.position().subtract(caster.position());
        away = new Vec3(away.x, 0, away.z);
        away = away.lengthSqr() < 1.0E-6 ? new Vec3(0, 0, 0) : away.normalize();
        switch (n) {
            case "fire" -> t.setRemainingFireTicks(Math.max(t.getRemainingFireTicks(), ticks));
            case "freeze" -> t.setTicksFrozen(t.getTicksFrozen() + ticks);
            case "knockback" -> { t.push(away.x * 0.6 * (amp + 1), 0.3, away.z * 0.6 * (amp + 1)); t.hurtMarked = true; }
            case "launch" -> { t.push(0, 0.7 * (amp + 1), 0); t.hurtMarked = true; }
            case "pull" -> { t.push(-away.x * 0.8 * (amp + 1), 0.2, -away.z * 0.8 * (amp + 1)); t.hurtMarked = true; }
            case "lightning" -> {
                if (t.level() instanceof ServerLevel sl) {
                    LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
                    if (bolt != null) {
                        bolt.moveTo(t.getX(), t.getY(), t.getZ());
                        bolt.setVisualOnly(true);
                        sl.addFreshEntity(bolt);
                    }
                }
            }
            case "stun" -> {
                t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 6));
                t.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, ticks, 3));
            }
            case "sleep" -> {
                t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 6));
                t.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, ticks, 0));
            }
            case "charm" -> {
                if (t instanceof Mob m) m.setTarget(null);
                t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, ticks, 1));
            }
            case "fear" -> {
                t.push(away.x * 0.9, 0.3, away.z * 0.9);
                t.hurtMarked = true;
                t.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, ticks, 0));
            }
            default -> {
                Holder<MobEffect> h = potion(n);
                if (h != null) t.addEffect(new MobEffectInstance(h, ticks, amp), caster);
            }
        }
    }
}
