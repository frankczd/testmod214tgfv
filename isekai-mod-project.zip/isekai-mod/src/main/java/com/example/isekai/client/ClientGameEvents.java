package com.example.isekai.client;

import com.example.isekai.CastSkillPayload;
import com.example.isekai.IsekaiMod;
import com.example.isekai.SkillListPayload;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = IsekaiMod.MODID, value = Dist.CLIENT)
public class ClientGameEvents {
    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        while (ClientModEvents.OPEN_STATUS.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new StatusScreen());
        }
        while (ClientModEvents.NEXT_SKILL.consumeClick()) ClientCasting.step(1);
        while (ClientModEvents.PREV_SKILL.consumeClick()) ClientCasting.step(-1);
        while (ClientModEvents.CAST_SKILL.consumeClick()) {
            SkillListPayload.Entry sel = ClientCasting.selected();
            if (mc.player != null && mc.screen == null && sel != null) {
                PacketDistributor.sendToServer(new CastSkillPayload(sel.id()));
            }
        }
    }
}
