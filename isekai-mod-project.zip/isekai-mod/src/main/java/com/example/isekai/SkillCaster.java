package com.example.isekai;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/** Server side of hotkey casting: checks MP and cooldown, then runs the skill's cast effect. */
public final class SkillCaster {
    private SkillCaster() {}

    private static final Map<UUID, Map<String, Long>> COOLDOWNS = new HashMap<>();

    public static void cast(ServerPlayer p, String id) {
        Skill d = SkillDefs.get(id);
        SkillState st = SkillManager.get(p).get(id);
        if (d == null || st == null || st.level() < 1 || !d.fx().cast().castable()) return;
        Skill.SkillFx.Cast c = d.fx().cast();

        long now = p.level().getGameTime();
        Map<String, Long> cds = COOLDOWNS.computeIfAbsent(p.getUUID(), k -> new HashMap<>());
        if (now < cds.getOrDefault(id, 0L)) {
            p.displayClientMessage(Component.literal(d.name() + " is recharging"), true);
            return;
        }

        PlayerStats s = StatsManager.get(p);
        double discount = Math.min(60, SkillManager.passiveTotal(p, "mp_discount"));
        int cost = (int) Math.round(c.mp() * (1 - discount / 100.0));
        if (s.mp() < cost) {
            p.displayClientMessage(Component.literal("Not enough MP for " + d.name()), true);
            return;
        }

        int lv = st.level();
        int magic = StatsManager.totals(p, s)[2];
        double mult = (1 + magic / 100.0) * (1 + SkillManager.passiveTotal(p, "magic_power") / 100.0);
        double power = (c.power() + c.powerPerLevel() * lv) * mult;
        int ticks = (int) Math.round((c.seconds() + c.secondsPerLevel() * lv) * 20);

        boolean ok = switch (c.kind()) {
            case "bolt" -> bolt(p, c, power, ticks);
            case "self" -> { SkillEffects.self(p, c.effect(), ticks, c.amp()); yield true; }
            case "heal" -> {
                p.heal((float) power);
                if (!c.effect().isEmpty()) SkillEffects.self(p, c.effect(), ticks, c.amp());
                yield true;
            }
            case "dash" -> dash(p, c.range());
            case "reveal" -> reveal(p, c.range(), Math.max(100, ticks));
            case "synth" -> synth(p, c.effect());
            case "appraise" -> appraise(p, c.range());
            default -> false;
        };
        if (!ok) return;

        StatsManager.save(p, StatsManager.get(p).withMp(Math.max(0, StatsManager.get(p).mp() - cost)));
        double cdr = Math.min(60, SkillManager.passiveTotal(p, "cooldown"));
        cds.put(id, now + Math.round(c.cooldown() * 20 * (1 - cdr / 100.0)));
        SkillManager.train(p, "cast_" + id, 1);
    }

    /** First living thing along your line of sight. */
    private static LivingEntity target(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getViewVector(1.0F);
        Vec3 end = eye.add(look.scale(range));
        AABB box = p.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(p, eye, end, box,
                e -> e instanceof LivingEntity && !e.isSpectator() && e.isPickable(), range * range);
        return hit != null && hit.getEntity() instanceof LivingEntity le ? le : null;
    }

    private static boolean bolt(ServerPlayer p, Skill.SkillFx.Cast c, double power, int ticks) {
        LivingEntity t = target(p, c.range());
        if (t == null) {
            p.displayClientMessage(Component.literal("No target in sight"), true);
            return false;
        }
        // direct entity null = not counted as a melee hit, so it doesn't trigger Poison Fang etc.
        if (power > 0) t.hurt(p.damageSources().indirectMagic(null, p), (float) power);
        if (!c.effect().isEmpty()) SkillEffects.apply(p, t, c.effect(), ticks, c.amp());
        return true;
    }

    private static boolean dash(ServerPlayer p, double range) {
        Vec3 start = p.position();
        Vec3 dir = p.getLookAngle().normalize();
        Vec3 best = start;
        for (double d = 1; d <= range; d += 1) {
            Vec3 next = start.add(dir.scale(d));
            AABB box = p.getBoundingBox().move(next.subtract(start));
            if (!p.level().noCollision(p, box)) break;
            best = next;
        }
        if (best.equals(start)) return false;
        p.teleportTo(best.x, best.y, best.z);
        p.fallDistance = 0;
        return true;
    }

    private static boolean reveal(ServerPlayer p, double radius, int ticks) {
        List<LivingEntity> found = p.level().getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(radius), e -> e != p && e instanceof Enemy && e.isAlive());
        for (LivingEntity e : found) SkillEffects.apply(p, e, "glow", ticks, 0);
        p.displayClientMessage(Component.literal(found.size() + " hostile(s) within " + (int) radius + " blocks"), true);
        return true;
    }

    private static boolean synth(ServerPlayer p, String kind) {
        ItemStack out = "poison".equals(kind)
                ? PotionContents.createItemStack(Items.POTION, Potions.POISON)
                : PotionContents.createItemStack(Items.POTION, Potions.HEALING);
        if (!p.addItem(out)) p.drop(out, false);
        return true;
    }

    /** Reads a target's stats. Players with a species show their level and species. */
    private static boolean appraise(ServerPlayer p, double range) {
        LivingEntity t = target(p, range);
        if (t == null) {
            p.displayClientMessage(Component.literal("Nothing to appraise in sight"), true);
            return false;
        }
        StringBuilder sb = new StringBuilder("[Appraisal] " + t.getName().getString());
        if (t instanceof ServerPlayer tp) {
            PlayerStats ts = StatsManager.get(tp);
            Species sp = SpeciesManager.get(ts.species());
            if (sp != null) sb.append(" | ").append(sp.name()).append(" Lv ").append(ts.level());
        }
        sb.append(String.format(" | HP %.0f/%.0f", t.getHealth(), t.getMaxHealth()));
        if (t.getAttribute(Attributes.ATTACK_DAMAGE) != null)
            sb.append(String.format(" | Offense %.1f", t.getAttributeValue(Attributes.ATTACK_DAMAGE)));
        sb.append(String.format(" | Defense %.1f", t.getAttributeValue(Attributes.ARMOR)));
        sb.append(String.format(" | Speed %.2f", t.getAttributeValue(Attributes.MOVEMENT_SPEED)));
        p.sendSystemMessage(Component.literal(sb.toString()));
        return true;
    }
}
