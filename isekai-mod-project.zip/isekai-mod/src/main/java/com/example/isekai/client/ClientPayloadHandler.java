package com.example.isekai.client;

import com.example.isekai.ClientSkills;
import com.example.isekai.ClientSpecies;
import com.example.isekai.SkillListPayload;
import com.example.isekai.SyncSkillsPayload;
import com.example.isekai.ClientStats;
import com.example.isekai.SpeciesListPayload;
import com.example.isekai.SyncStatsPayload;
import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Client-only packet handlers (kept in their own class so servers never load it). */
public class ClientPayloadHandler {
    public static void sync(SyncStatsPayload p, IPayloadContext ctx) {
        ClientStats.set(p.stats(), p.totals(), p.maxMp());
        Minecraft mc = Minecraft.getInstance();
        if (p.stats().species().isEmpty() && mc.screen == null && !ClientSpecies.startOptions().isEmpty()) {
            mc.setScreen(new SpeciesSelectScreen());
        }
    }

    public static void species(SpeciesListPayload p, IPayloadContext ctx) {
        ClientSpecies.set(p.entries());
    }

    public static void skills(SyncSkillsPayload p, IPayloadContext ctx) { ClientSkills.setOwned(p.skills()); }

    public static void skillList(SkillListPayload p, IPayloadContext ctx) { ClientSkills.setDefs(p.entries()); }
}
