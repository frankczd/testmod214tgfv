package com.example.isekai;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;

/** Loads species JSON from data packs. Edit a file, run /reload, no Java changes needed. Registered in StatsEvents. */
public class SpeciesManager extends SimpleJsonResourceReloadListener {
    public static final SpeciesManager INSTANCE = new SpeciesManager();
    private static Map<String, Species> species = new LinkedHashMap<>();

    private SpeciesManager() { super(new Gson(), "species"); }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> files, ResourceManager rm, ProfilerFiller profiler) {
        Map<String, Species> loaded = new LinkedHashMap<>();
        files.forEach((id, json) -> Species.CODEC.parse(JsonOps.INSTANCE, json)
                .resultOrPartial(err -> System.err.println("[isekai] bad species " + id + ": " + err))
                .ifPresent(s -> loaded.put(id.getPath(), s)));
        species = loaded;
    }

    public static Species get(String id) { return species.get(id); }

    public static int maxLevel(String id) {
        Species s = species.get(id);
        return s == null ? 100 : s.maxLevel();
    }

    public static SpeciesListPayload listPayload() {
        List<SpeciesListPayload.Entry> out = new ArrayList<>();
        species.forEach((id, s) -> out.add(new SpeciesListPayload.Entry(
                id, s.name(), s.description(), s.start(), s.maxLevel(), s.evolvesTo())));
        return new SpeciesListPayload(out);
    }
}
