package com.example.isekai.client;

import com.example.isekai.ClientSpecies;
import com.example.isekai.PickSpeciesPayload;
import com.example.isekai.SpeciesListPayload.Entry;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.neoforged.neoforge.network.PacketDistributor;

/** Shown when you have no species. Pick a start, then Begin. */
public class SpeciesSelectScreen extends Screen {
    private final List<Entry> options = ClientSpecies.startOptions();
    private int selected = 0;

    public SpeciesSelectScreen() { super(Component.literal("Choose your species")); }

    @Override
    protected void init() {
        int left = width / 2 - 150, top = height / 2 - 80;
        for (int i = 0; i < options.size(); i++) {
            final int idx = i;
            addRenderableWidget(Button.builder(Component.literal(options.get(i).name()), b -> selected = idx)
                    .bounds(left, top + i * 24, 110, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Begin"), b -> {
            PacketDistributor.sendToServer(new PickSpeciesPayload(options.get(selected).id()));
            onClose();
        }).bounds(left + 130, top + 150, 170, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0xE0000000);
        super.render(g, mx, my, pt);
        if (options.isEmpty()) return;
        int left = width / 2 - 150, top = height / 2 - 80;
        g.drawCenteredString(font, "Choose your species", width / 2, top - 24, 0xFFD700);
        Entry e = options.get(selected);
        g.drawString(font, e.name(), left + 130, top, 0xFFFFFF);
        List<FormattedCharSequence> lines = font.split(Component.literal(e.description()), 170);
        for (int i = 0; i < lines.size(); i++) g.drawString(font, lines.get(i), left + 130, top + 14 + i * 10, 0xB0B0C0);
    }

    @Override public void renderBackground(GuiGraphics g, int mx, int my, float pt) {}
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }
}
