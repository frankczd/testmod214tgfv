package com.example.isekai.client;

import com.example.isekai.AllocatePointPayload;
import com.example.isekai.ClientSpecies;
import com.example.isekai.ClientStats;
import com.example.isekai.PickSpeciesPayload;
import com.example.isekai.PlayerStats;
import com.example.isekai.SpeciesListPayload.Entry;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** The "status window". Press K in game. */
public class StatusScreen extends Screen {
    private static final int W = 230, H = 250;
    private final List<Button> plusButtons = new ArrayList<>();
    private final List<Button> evolveButtons = new ArrayList<>();
    private String builtFor = "";

    public StatusScreen() { super(Component.literal("Status")); }

    private int left() { return (width - W) / 2; }
    private int top() { return (height - H) / 2; }

    @Override
    protected void init() {
        plusButtons.clear();
        evolveButtons.clear();
        builtFor = ClientStats.get().species();
        for (int i = 0; i < 5; i++) {
            final int idx = i;
            Button b = Button.builder(Component.literal("+"),
                            btn -> PacketDistributor.sendToServer(new AllocatePointPayload(idx)))
                    .bounds(left() + W - 30, top() + 113 + i * 16, 16, 14).build();
            plusButtons.add(b);
            addRenderableWidget(b);
        }
        addRenderableWidget(Button.builder(Component.literal("Skills"), b -> Minecraft.getInstance().setScreen(new SkillsScreen()))
                .bounds(left() + W - 80, top() + H - 26, 70, 16).build());
        Entry cur = ClientSpecies.get(builtFor);
        if (cur != null && !cur.evolvesTo().isEmpty()) {
            int n = cur.evolvesTo().size();
            int bw = (W - 20 - (n - 1) * 4) / n;
            for (int i = 0; i < n; i++) {
                String id = cur.evolvesTo().get(i);
                Entry target = ClientSpecies.get(id);
                Button b = Button.builder(Component.literal(target != null ? target.name() : id),
                                btn -> PacketDistributor.sendToServer(new PickSpeciesPayload(id)))
                        .bounds(left() + 10 + i * (bw + 4), top() + 204, bw, 16).build();
                evolveButtons.add(b);
                addRenderableWidget(b);
            }
        }
    }

    @Override
    public void tick() {
        if (!ClientStats.get().species().equals(builtFor)) rebuildWidgets(); // evolved while open
    }

    public static void bar(GuiGraphics g, int x, int y, int w, int h, float frac, int color) {
        frac = Math.max(0f, Math.min(1f, frac));
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        g.fill(x, y, x + w, y + h, 0xFF2A2A33);
        g.fill(x, y, x + (int) (w * frac), y + h, color);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        Minecraft mc = Minecraft.getInstance();
        PlayerStats s = ClientStats.get();
        int[] tot = ClientStats.totals();
        int max = ClientStats.maxMp();
        Entry sp = ClientSpecies.get(s.species());
        boolean canEvolve = sp != null && s.level() >= sp.maxLevel() && !sp.evolvesTo().isEmpty();
        int l = left(), t = top();

        g.fill(0, 0, width, height, 0x90000000);
        g.fill(l - 2, t - 2, l + W + 2, t + H + 2, 0xFF6A5ACD);
        g.fill(l, t, l + W, t + H, 0xFF12121C);

        for (Button b : plusButtons) b.active = s.points() > 0;
        for (Button b : evolveButtons) b.visible = canEvolve;
        super.render(g, mx, my, pt);

        g.drawString(font, "STATUS WINDOW", l + 10, t + 10, 0xFFD700);
        g.drawString(font, "Name: " + mc.player.getName().getString(), l + 10, t + 26, 0xFFFFFF);
        g.drawString(font, "Species: " + (sp != null ? sp.name() : "-") + "   Lv " + s.level()
                + (sp != null ? "/" + sp.maxLevel() : ""), l + 10, t + 38, 0xFFFFFF);

        float hp = mc.player.getHealth(), maxHp = mc.player.getMaxHealth();
        g.drawString(font, String.format("HP  %.0f / %.0f", hp / PlayerStats.HP_SCALE, maxHp / PlayerStats.HP_SCALE), l + 10, t + 56, 0xFF6060);
        bar(g, l + 110, t + 57, 100, 7, hp / maxHp, 0xFFC03030);

        g.drawString(font, "MP  " + s.mp() + " / " + max, l + 10, t + 70, 0x6090FF);
        bar(g, l + 110, t + 71, 100, 7, s.mp() / (float) max, 0xFF3A7BFF);

        g.drawString(font, "EXP " + s.xp() + " / " + s.xpToNext(), l + 10, t + 84, 0xE0B030);
        bar(g, l + 110, t + 85, 100, 7, s.xp() / (float) s.xpToNext(), 0xFFE0B030);

        g.drawString(font, "Stat points: " + s.points(), l + 10, t + 100, 0x80FF80);
        g.drawString(font, "Skill points: " + s.skillPoints(), l + 110, t + 100, 0xA0A0FF);
        g.drawString(font, "Skill points: " + s.skillPoints(), l + 120, t + 100, 0xC0A0FF);
        for (int i = 0; i < 5; i++) {
            int y = t + 116 + i * 16;
            g.drawString(font, PlayerStats.STAT_NAMES[i], l + 10, y, 0xFFFFFF);
            g.drawString(font, String.valueOf(tot[i]), l + 110, y, 0xFFFFFF);
        }
        if (canEvolve) g.drawString(font, "Max level! Evolve:", l + 10, t + 192, 0xFFD700);
        g.drawString(font, "[K] close", l + 10, t + H - 14, 0x808090);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float pt) {}

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (ClientModEvents.OPEN_STATUS.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
