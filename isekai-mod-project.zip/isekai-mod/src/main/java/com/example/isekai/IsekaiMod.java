package com.example.isekai;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(IsekaiMod.MODID)
public class IsekaiMod {
    public static final String MODID = "isekai";

    public IsekaiMod(IEventBus modBus) {
        ModAttachments.ATTACHMENTS.register(modBus);
    }
}
