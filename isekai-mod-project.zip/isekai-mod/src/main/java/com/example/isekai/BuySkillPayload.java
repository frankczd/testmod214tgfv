package com.example.isekai;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: spend skill points to learn a skill. */
public record BuySkillPayload(String id) implements CustomPacketPayload {
    public static final Type<BuySkillPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "buy_skill"));

    public static final StreamCodec<ByteBuf, BuySkillPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.STRING_UTF8, BuySkillPayload::id, BuySkillPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
