package com.example.isekai;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: stats plus the server-computed totals (species base + growth + spent points). */
public record SyncStatsPayload(PlayerStats stats, int[] totals, int maxMp) implements CustomPacketPayload {
    public static final Type<SyncStatsPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "sync_stats"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SyncStatsPayload> CODEC = StreamCodec.of(
            (buf, p) -> {
                p.stats().write(buf);
                for (int i = 0; i < 5; i++) buf.writeVarInt(p.totals()[i]);
                buf.writeVarInt(p.maxMp());
            },
            buf -> {
                PlayerStats s = PlayerStats.read(buf);
                int[] t = new int[5];
                for (int i = 0; i < 5; i++) t[i] = buf.readVarInt();
                return new SyncStatsPayload(s, t, buf.readVarInt());
            });

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
