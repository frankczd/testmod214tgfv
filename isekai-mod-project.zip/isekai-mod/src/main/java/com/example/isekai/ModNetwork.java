package com.example.isekai;

import com.example.isekai.client.ClientPayloadHandler;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@EventBusSubscriber(modid = IsekaiMod.MODID, bus = EventBusSubscriber.Bus.MOD)
public class ModNetwork {

    @SubscribeEvent
    public static void register(RegisterPayloadHandlersEvent e) {
        PayloadRegistrar r = e.registrar("4");

        r.playToClient(SyncStatsPayload.TYPE, SyncStatsPayload.CODEC, ClientPayloadHandler::sync);
        r.playToClient(SpeciesListPayload.TYPE, SpeciesListPayload.CODEC, ClientPayloadHandler::species);


        r.playToClient(SyncSkillsPayload.TYPE, SyncSkillsPayload.CODEC, ClientPayloadHandler::skills);
        r.playToClient(SkillListPayload.TYPE, SkillListPayload.CODEC, ClientPayloadHandler::skillList);
        r.playToServer(CastSkillPayload.TYPE, CastSkillPayload.CODEC, (payload, ctx) -> {
            if (ctx.player() instanceof ServerPlayer sp) SkillCaster.cast(sp, payload.id());
        });
        r.playToServer(BuySkillPayload.TYPE, BuySkillPayload.CODEC, (payload, ctx) -> {
            if (ctx.player() instanceof ServerPlayer sp) SkillManager.buy(sp, payload.id());
        });

        r.playToServer(AllocatePointPayload.TYPE, AllocatePointPayload.CODEC, (payload, ctx) -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                PlayerStats cur = StatsManager.get(sp);
                PlayerStats next = cur.spend(payload.stat());
                if (next != cur) {
                    StatsManager.save(sp, next);
                    StatsManager.refresh(sp);
                }
            }
        });

        r.playToServer(PickSpeciesPayload.TYPE, PickSpeciesPayload.CODEC, (payload, ctx) -> {
            if (ctx.player() instanceof ServerPlayer sp) StatsManager.pickSpecies(sp, payload.id());
        });
    }
}
