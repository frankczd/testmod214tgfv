package com.example.isekai.client;

import com.example.isekai.BuySkillPayload;
import com.example.isekai.ClientSkills;
import com.example.isekai.ClientStats;
import com.example.isekai.Skill;
import com.example.isekai.SkillListPayload;
import com.example.isekai.SkillState;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.neoforged.neoforge.network.PacketDistributor;

/** Owned skills with level/progress, plus skills you are learning or can buy. Hover for details. */
public class SkillsScreen extends Screen {
    private static final int W = 250, H = 232, PER_PAGE = 7;
    /** state: owned skill (level >= 1), learning progress (level 0), or null. */
    private record Row(SkillListPayload.Entry def, SkillState state) {
        boolean owned() { return state != null && state.level() >= 1; }
    }

    private int page = 0;
    private int seenVersion = -1;
    private List<Row> all = new ArrayList<>();
    private final List<Button> buyButtons = new ArrayList<>();
    private final List<Integer> buyCosts = new ArrayList<>();

    public SkillsScreen() { super(Component.literal("Skills")); }

    private int left() { return (width - W) / 2; }
    private int top() { return (height - H) / 2; }

    private void collect() {
        all = new ArrayList<>();
        for (Map.Entry<String, SkillState> e : ClientSkills.owned().entrySet()) {
            if (e.getValue().level() < 1) continue;
            SkillListPayload.Entry d = ClientSkills.def(e.getKey());
            if (d == null) d = new SkillListPayload.Entry(e.getKey(), e.getKey(), "", 1, 10, 0, 0, -1, List.of());
            all.add(new Row(d, e.getValue()));
        }
        for (SkillListPayload.Entry d : ClientSkills.defs()) {
            boolean obtainable = d.cost() > 0 || d.learnAmount() > 0;
            if (obtainable && !ClientSkills.owns(d.id()) && !ClientSkills.ownsDescendant(d.id())) {
                all.add(new Row(d, ClientSkills.owned().get(d.id())));
            }
        }
    }

    @Override
    protected void init() {
        seenVersion = ClientSkills.version();
        collect();
        buyButtons.clear();
        buyCosts.clear();
        int pages = Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.min(page, pages - 1);
        int l = left(), t = top();
        for (int i = 0; i < PER_PAGE && page * PER_PAGE + i < all.size(); i++) {
            Row r = all.get(page * PER_PAGE + i);
            if (!r.owned() && r.def().cost() > 0) {
                Button b = Button.builder(Component.literal("Buy " + r.def().cost()),
                                btn -> PacketDistributor.sendToServer(new BuySkillPayload(r.def().id())))
                        .bounds(l + W - 70, t + 38 + i * 24, 58, 16).build();
                buyButtons.add(b);
                buyCosts.add(r.def().cost());
                addRenderableWidget(b);
            }
        }
        addRenderableWidget(Button.builder(Component.literal("<"), b -> { page = Math.max(0, page - 1); rebuildWidgets(); })
                .bounds(l + 10, t + H - 24, 20, 16).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> { page = Math.min(pages - 1, page + 1); rebuildWidgets(); })
                .bounds(l + 34, t + H - 24, 20, 16).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> minecraft.setScreen(new StatusScreen()))
                .bounds(l + W - 70, t + H - 24, 58, 16).build());
    }

    @Override
    public void tick() {
        if (seenVersion != ClientSkills.version()) rebuildWidgets();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        int l = left(), t = top();
        int points = ClientStats.get().skillPoints();
        g.fill(0, 0, width, height, 0x90000000);
        g.fill(l - 2, t - 2, l + W + 2, t + H + 2, 0xFF6A5ACD);
        g.fill(l, t, l + W, t + H, 0xFF12121C);

        for (int i = 0; i < buyButtons.size(); i++) buyButtons.get(i).active = points >= buyCosts.get(i);
        super.render(g, mx, my, pt);

        g.drawString(font, "SKILLS", l + 10, t + 10, 0xFFD700);
        g.drawString(font, "Skill points: " + points, l + 100, t + 10, 0xA0A0FF);
        if (all.isEmpty()) g.drawString(font, "No skills yet.", l + 10, t + 40, 0x808090);

        List<FormattedCharSequence> tooltip = null;
        for (int i = 0; i < PER_PAGE && page * PER_PAGE + i < all.size(); i++) {
            Row r = all.get(page * PER_PAGE + i);
            int y = t + 36 + i * 24;
            boolean hover = mx >= l + 8 && mx <= l + W - 8 && my >= y && my <= y + 22;
            g.fill(l + 8, y, l + W - 8, y + 22, hover ? 0x40FFFFFF : 0x20FFFFFF);
            String tier = r.def().tier() > 1 ? "  (T" + r.def().tier() + ")" : "";
            if (r.owned()) {
                int lv = r.state().level();
                g.drawString(font, r.def().name() + tier + "   Lv " + lv + "/" + r.def().maxLevel(), l + 12, y + 3, 0xFFFFFF);
                int need = Skill.xpNeeded(lv, r.def().tier());
                StatusScreen.bar(g, l + 12, y + 15, 150, 3,
                        lv >= r.def().maxLevel() ? 1f : r.state().xp() / (float) need, 0xFF60C060);
            } else if (r.def().learnAmount() > 0) {
                int prog = r.state() == null ? 0 : r.state().xp();
                g.drawString(font, r.def().name() + tier + "   learning " + prog + "/" + r.def().learnAmount(),
                        l + 12, y + 3, 0x9AA0C0);
                StatusScreen.bar(g, l + 12, y + 15, 150, 3, prog / (float) r.def().learnAmount(), 0xFF6080D0);
            } else {
                g.drawString(font, r.def().name() + tier, l + 12, y + 7, 0x9AA0C0);
            }
            if (hover && !r.def().description().isEmpty()) {
                tooltip = font.split(Component.literal(r.def().description()), 200);
            }
        }
        int pages = Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
        g.drawString(font, (page + 1) + "/" + pages, l + 62, t + H - 20, 0x808090);
        if (tooltip != null) g.renderTooltip(font, tooltip, mx, my);
    }

    @Override public void renderBackground(GuiGraphics g, int mx, int my, float pt) {}
    @Override public boolean isPauseScreen() { return false; }
}
