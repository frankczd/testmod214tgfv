package com.example.isekai;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: choose a starting species (if none yet) or evolve into one. Server validates. */
public record PickSpeciesPayload(String id) implements CustomPacketPayload {
    public static final Type<PickSpeciesPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "pick_species"));
    public static final StreamCodec<ByteBuf, PickSpeciesPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.STRING_UTF8, PickSpeciesPayload::id, PickSpeciesPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
