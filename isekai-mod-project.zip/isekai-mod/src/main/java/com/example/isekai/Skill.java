package com.example.isekai;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;

/**
 * A skill definition from data/isekai/skills/<id>.json.
 * Stat skills follow the series: tier 1 adds 1 per skill level, tier 2 adds 10, tier 3 adds 100.
 * growth_per_level adds extra stat every character level (this is what makes stats snowball).
 * stat: offense, defense, magic, resistance, speed, hp, mp, or all (= the five main stats).
 * fx: optional extra effects (on-hit damage/status, damage resistance, passive potion effect).
 * learn_on + learn_amount: you learn the skill by doing the action enough times (no points needed).
 * cost: skill points to buy it instead (0 = can't be bought).
 * train_on: the action that levels it once you have it.
 */
public record Skill(String name, String description, int tier, int maxLevel, String stat,
                    double flatPerLevel, double growthPerLevel,
                    double hpRegenPct, double mpRegenPct,
                    int cost, String trainOn, int trainXp,
                    String learnOn, int learnAmount, List<String> evolvesTo, SkillFx fx) {

    public static final Codec<Skill> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.STRING.fieldOf("name").forGetter(Skill::name),
            Codec.STRING.optionalFieldOf("description", "").forGetter(Skill::description),
            Codec.INT.optionalFieldOf("tier", 1).forGetter(Skill::tier),
            Codec.INT.optionalFieldOf("max_level", 10).forGetter(Skill::maxLevel),
            Codec.STRING.optionalFieldOf("stat", "").forGetter(Skill::stat),
            Codec.DOUBLE.optionalFieldOf("flat_per_level", 0.0).forGetter(Skill::flatPerLevel),
            Codec.DOUBLE.optionalFieldOf("growth_per_level", 0.0).forGetter(Skill::growthPerLevel),
            Codec.DOUBLE.optionalFieldOf("hp_regen_pct", 0.0).forGetter(Skill::hpRegenPct),
            Codec.DOUBLE.optionalFieldOf("mp_regen_pct", 0.0).forGetter(Skill::mpRegenPct),
            Codec.INT.optionalFieldOf("cost", 0).forGetter(Skill::cost),
            Codec.STRING.optionalFieldOf("train_on", "").forGetter(Skill::trainOn),
            Codec.INT.optionalFieldOf("train_xp", 1).forGetter(Skill::trainXp),
            Codec.STRING.optionalFieldOf("learn_on", "").forGetter(Skill::learnOn),
            Codec.INT.optionalFieldOf("learn_amount", 0).forGetter(Skill::learnAmount),
            Codec.STRING.listOf().optionalFieldOf("evolves_to", List.of()).forGetter(Skill::evolvesTo),
            SkillFx.CODEC.optionalFieldOf("fx", SkillFx.NONE).forGetter(Skill::fx)
    ).apply(i, Skill::new));

    /** 0-4 = Offense..Speed, 5 = HP, 6 = MP, -1 = not a stat skill. */
    public int statIndex() {
        return switch (stat) {
            case "offense" -> 0;
            case "defense" -> 1;
            case "magic" -> 2;
            case "resistance" -> 3;
            case "speed" -> 4;
            case "hp" -> 5;
            case "mp" -> 6;
            case "all" -> 7; // every stat (Offense..Speed), used by Demon Lord / Hero
            case "physical" -> 8; // Offense, Defense and Speed
            default -> -1;
        };
    }

    /** Higher tiers level slower: x1, x3, x10. */
    public static int xpNeeded(int level, int tier) {
        double scale = tier <= 1 ? 1 : tier == 2 ? 3 : 10;
        return (int) Math.round((15 + 10 * level) * scale);
    }

    /**
     * Extra effects.
     * hit_damage: bonus melee damage per skill level. hit_effect (poison, fire, freeze, slowness, weakness, wither)
     * lasts hit_seconds per skill level. resist: damage categories reduced by resist_pct percent per skill level
     * (physical, projectile, impact, blast, fire, magic, wither, drown, freeze, lightning, earth).
     * passive + passive_power: a permanent effect while owned (night_vision, flight, camouflage, swim,
     * intimidate, vampire, dodge, sword, unarmed, magic_power, mp_discount, cooldown, skill_xp).
     * cast: makes the skill something you cast with a hotkey (see Cast).
     */
    public record SkillFx(double hitDamage, String hitEffect, double hitSeconds,
                          List<String> resist, double resistPct, String passive, double passivePower, Cast cast) {
        public static final SkillFx NONE = new SkillFx(0, "", 0, List.of(), 0, "", 0, Cast.NONE);

        public static final Codec<SkillFx> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.DOUBLE.optionalFieldOf("hit_damage", 0.0).forGetter(SkillFx::hitDamage),
                Codec.STRING.optionalFieldOf("hit_effect", "").forGetter(SkillFx::hitEffect),
                Codec.DOUBLE.optionalFieldOf("hit_seconds", 0.0).forGetter(SkillFx::hitSeconds),
                Codec.STRING.listOf().optionalFieldOf("resist", List.of()).forGetter(SkillFx::resist),
                Codec.DOUBLE.optionalFieldOf("resist_pct", 0.0).forGetter(SkillFx::resistPct),
                Codec.STRING.optionalFieldOf("passive", "").forGetter(SkillFx::passive),
                Codec.DOUBLE.optionalFieldOf("passive_power", 0.0).forGetter(SkillFx::passivePower),
                Cast.CODEC.optionalFieldOf("cast", Cast.NONE).forGetter(SkillFx::cast)
        ).apply(i, SkillFx::new));

        /**
         * kind: bolt (aim at a target in range), self (buff yourself), heal, dash (blink forward),
         * reveal (highlight nearby monsters), synth (make a potion), appraise (read a target's stats).
         * power/power_per_level: damage or healing. effect: one or more comma separated effects
         * (poison, slowness, weakness, wither, blind, nausea, darkness, glow, levitate, fire, freeze,
         * knockback, launch, pull, lightning, stun, charm, fear, sleep, regeneration, resistance,
         * strength, speed, absorption...). seconds + seconds_per_level set the duration.
         */
        public record Cast(String kind, int mp, double cooldown, double range, double power, double powerPerLevel,
                           String effect, double seconds, double secondsPerLevel, int amp) {
            public static final Cast NONE = new Cast("", -1, 0, 0, 0, 0, "", 0, 0, 0);

            public static final Codec<Cast> CODEC = RecordCodecBuilder.create(i -> i.group(
                    Codec.STRING.optionalFieldOf("kind", "").forGetter(Cast::kind),
                    Codec.INT.optionalFieldOf("mp", 0).forGetter(Cast::mp),
                    Codec.DOUBLE.optionalFieldOf("cooldown", 1.0).forGetter(Cast::cooldown),
                    Codec.DOUBLE.optionalFieldOf("range", 20.0).forGetter(Cast::range),
                    Codec.DOUBLE.optionalFieldOf("power", 0.0).forGetter(Cast::power),
                    Codec.DOUBLE.optionalFieldOf("power_per_level", 0.0).forGetter(Cast::powerPerLevel),
                    Codec.STRING.optionalFieldOf("effect", "").forGetter(Cast::effect),
                    Codec.DOUBLE.optionalFieldOf("seconds", 0.0).forGetter(Cast::seconds),
                    Codec.DOUBLE.optionalFieldOf("seconds_per_level", 0.0).forGetter(Cast::secondsPerLevel),
                    Codec.INT.optionalFieldOf("amp", 0).forGetter(Cast::amp)
            ).apply(i, Cast::new));

            public boolean castable() { return !kind.isEmpty(); }
        }
    }
}
