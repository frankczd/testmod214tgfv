package com.example.isekai;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;

/**
 * A species from data/isekai/species/<id>.json.
 * base_stats / growth are ordered Offense, Defense, Magic, Resistance, Speed.
 * HP/MP use canon-style numbers (Minecraft max health = HP * HP_SCALE). skills = "id:level".
 * scale = body size as a multiple of the player's (1.0 = normal, 0.25 = tiny, 11 = enormous).
 */
public record Species(String name, String description, boolean start, int maxLevel,
                      List<Integer> baseStats, List<Double> growth, List<String> evolvesTo,
                      int baseHp, double hpGrowth, int baseMp, double mpGrowth, List<String> skills,
                      int skillPoints, double skillPointBonus, int evolutionSkillPoints, double scale) {

    private static final List<Integer> ZEROS = List.of(0, 0, 0, 0, 0);

    /** Skill points gained per level, including the species bonus (e.g. humans +35%). */
    public int skillPointsPerLevel() { return (int) Math.round(skillPoints * (1.0 + skillPointBonus)); }

    public static final Codec<Species> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.STRING.fieldOf("name").forGetter(Species::name),
            Codec.STRING.optionalFieldOf("description", "").forGetter(Species::description),
            Codec.BOOL.optionalFieldOf("start", false).forGetter(Species::start),
            Codec.INT.optionalFieldOf("max_level", 10).forGetter(Species::maxLevel),
            Codec.INT.listOf().optionalFieldOf("base_stats", ZEROS).forGetter(Species::baseStats),
            Codec.DOUBLE.listOf().optionalFieldOf("growth", List.of(0.0, 0.0, 0.0, 0.0, 0.0)).forGetter(Species::growth),
            Codec.STRING.listOf().optionalFieldOf("evolves_to", List.of()).forGetter(Species::evolvesTo),
            Codec.INT.optionalFieldOf("base_hp", 20).forGetter(Species::baseHp),
            Codec.DOUBLE.optionalFieldOf("hp_growth", 1.0).forGetter(Species::hpGrowth),
            Codec.INT.optionalFieldOf("base_mp", 20).forGetter(Species::baseMp),
            Codec.DOUBLE.optionalFieldOf("mp_growth", 1.0).forGetter(Species::mpGrowth),
            Codec.STRING.listOf().optionalFieldOf("skills", List.of()).forGetter(Species::skills),
            Codec.INT.optionalFieldOf("skill_points", 20).forGetter(Species::skillPoints),
            Codec.DOUBLE.optionalFieldOf("skill_point_bonus", 0.0).forGetter(Species::skillPointBonus),
            Codec.INT.optionalFieldOf("evolution_skill_points", 100).forGetter(Species::evolutionSkillPoints),
            Codec.DOUBLE.optionalFieldOf("scale", 1.0).forGetter(Species::scale)
    ).apply(i, Species::new));
}
