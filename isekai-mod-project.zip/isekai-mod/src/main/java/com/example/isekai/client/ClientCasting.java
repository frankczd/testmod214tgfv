package com.example.isekai.client;

import com.example.isekai.ClientSkills;
import com.example.isekai.SkillListPayload;
import com.example.isekai.SkillState;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Which castable skill is currently selected on the hotkey. */
public final class ClientCasting {
    private static String selectedId = "";
    private ClientCasting() {}

    public static List<SkillListPayload.Entry> castable() {
        List<SkillListPayload.Entry> out = new ArrayList<>();
        for (Map.Entry<String, SkillState> e : ClientSkills.owned().entrySet()) {
            SkillListPayload.Entry d = ClientSkills.def(e.getKey());
            if (d != null && e.getValue().level() >= 1 && d.castMp() >= 0) out.add(d);
        }
        return out;
    }

    /** The selected skill, or the first castable one if none/invalid. Null if you have none. */
    public static SkillListPayload.Entry selected() {
        List<SkillListPayload.Entry> list = castable();
        if (list.isEmpty()) return null;
        for (SkillListPayload.Entry d : list) if (d.id().equals(selectedId)) return d;
        selectedId = list.get(0).id();
        return list.get(0);
    }

    public static void step(int dir) {
        List<SkillListPayload.Entry> list = castable();
        if (list.isEmpty()) return;
        int i = 0;
        for (int k = 0; k < list.size(); k++) if (list.get(k).id().equals(selectedId)) i = k;
        selectedId = list.get(Math.floorMod(i + dir, list.size())).id();
    }
}
