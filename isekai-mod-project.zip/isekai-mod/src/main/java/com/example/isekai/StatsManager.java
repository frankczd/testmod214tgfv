package com.example.isekai;

import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.PacketDistributor;

public final class StatsManager {
    private StatsManager() {}

    public static PlayerStats get(Player p) { return p.getData(ModAttachments.STATS); }

    private static int at(List<Integer> l, int i) { return i < l.size() ? l.get(i) : 0; }
    private static double atD(List<Double> l, int i) { return i < l.size() ? l.get(i) : 0.0; }

    /** Species base + species growth + points spent + skill bonuses. Offense, Defense, Magic, Resistance, Speed. */
    public static int[] totals(Player p, PlayerStats s) {
        Species sp = SpeciesManager.get(s.species());
        int[] t = new int[5];
        for (int i = 0; i < 5; i++) {
            double v = s.stat(i);
            if (sp != null) v += at(sp.baseStats(), i) + Math.floor(atD(sp.growth(), i) * (s.level() - 1));
            v += SkillManager.statBonus(p, s.level(), i);
            t[i] = (int) Math.round(v);
        }
        return t;
    }

    public static int maxMp(Player p, PlayerStats s) {
        Species sp = SpeciesManager.get(s.species());
        double v = sp == null ? 50 : sp.baseMp() + Math.floor(sp.mpGrowth() * (s.level() - 1));
        return (int) Math.round(v + SkillManager.statBonus(p, s.level(), 6));
    }

    /** Canon-style HP number. Minecraft max health is this times HP_SCALE. */
    public static int maxHp(Player p, PlayerStats s) {
        Species sp = SpeciesManager.get(s.species());
        double v = sp == null ? 40 : sp.baseHp() + Math.floor(sp.hpGrowth() * (s.level() - 1));
        return (int) Math.round(v + SkillManager.statBonus(p, s.level(), 5));
    }

    /** Save and sync to the client. */
    public static void save(ServerPlayer p, PlayerStats s) {
        p.setData(ModAttachments.STATS, s);
        PacketDistributor.sendToPlayer(p, new SyncStatsPayload(s, totals(p, s), maxMp(p, s)));
    }

    public static void giveXp(ServerPlayer p, int amount) {
        PlayerStats old = get(p);
        if (old.species().isEmpty()) return; // no XP until you've picked a start
        Species spc = SpeciesManager.get(old.species());
        PlayerStats now = old.addXp(amount, SpeciesManager.maxLevel(old.species()),
                spc == null ? 20 : spc.skillPointsPerLevel());
        boolean up = now.level() > old.level();
        if (up) now = now.withMp(maxMp(p, now));
        save(p, now);
        if (up) {
            refresh(p);
            p.setHealth(p.getMaxHealth());
            p.sendSystemMessage(Component.literal("Level up! Lv " + now.level()
                    + " (+" + (now.points() - old.points()) + " stat points, +" + (now.skillPoints() - old.skillPoints()) + " skill points)"));
            p.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 1f, 1f);
            Species sp = SpeciesManager.get(now.species());
            if (sp != null && now.level() >= sp.maxLevel() && !sp.evolvesTo().isEmpty()) {
                p.sendSystemMessage(Component.literal("You can evolve! Open the status window (K)."));
            }
        }
    }

    /** Pick a start (no species yet) or evolve (species has this id in evolves_to and you're at max level). */
    public static void pickSpecies(ServerPlayer p, String id) {
        PlayerStats s = get(p);
        Species target = SpeciesManager.get(id);
        if (target == null) return;
        if (s.species().isEmpty()) {
            if (!target.start()) return;
        } else {
            Species cur = SpeciesManager.get(s.species());
            if (cur == null || !cur.evolvesTo().contains(id) || s.level() < cur.maxLevel()) return;
        }
        PlayerStats n = s.withSpecies(id);
        if (!s.species().isEmpty()) n = n.addSkillPoints(target.evolutionSkillPoints()); // evolving grants a lump of skill points
        SkillManager.applySpeciesSkills(p, target);
        n = n.withMp(maxMp(p, n));
        save(p, n);
        refresh(p);
        p.setHealth(p.getMaxHealth());
        SkillManager.sync(p);
        p.sendSystemMessage(Component.literal(s.species().isEmpty()
                ? "You are now a " + target.name() + "."
                : "Evolved into " + target.name() + "!"));
    }

    /** Re-apply stat bonuses as attribute modifiers (not saved, so run on login/respawn/change). */
    public static void refresh(Player p) {
        PlayerStats s = get(p);
        int[] t = totals(p, s); // Offense, Defense, Magic, Resistance, Speed (canon-scale numbers)
        mod(p, Attributes.ATTACK_DAMAGE, "offense", t[0] * 0.1, Operation.ADD_VALUE);
        mod(p, Attributes.ARMOR, "defense_armor", t[1] * 0.1, Operation.ADD_VALUE);
        mod(p, Attributes.MAX_HEALTH, "hp", maxHp(p, s) * PlayerStats.HP_SCALE - 20.0, Operation.ADD_VALUE); // player base is 20
        mod(p, Attributes.ARMOR_TOUGHNESS, "resistance", t[3] * 0.05, Operation.ADD_VALUE);
        mod(p, Attributes.MOVEMENT_SPEED, "speed", t[4] * 0.002, Operation.ADD_MULTIPLIED_BASE);
        // Body size: scale the hitbox, step height and reach together so giants/tiny forms stay playable.
        Species spc = SpeciesManager.get(s.species());
        double scale = spc == null ? 1.0 : Math.max(0.0625, Math.min(16.0, spc.scale()));
        double reach = Math.max(scale, 0.6); // tiny forms keep a usable reach
        mod(p, Attributes.SCALE, "species_scale", scale - 1.0, Operation.ADD_VALUE);
        mod(p, Attributes.STEP_HEIGHT, "species_step", 0.6 * (reach - 1.0), Operation.ADD_VALUE);
        mod(p, Attributes.BLOCK_INTERACTION_RANGE, "species_reach", 4.5 * (reach - 1.0), Operation.ADD_VALUE);
        mod(p, Attributes.ENTITY_INTERACTION_RANGE, "species_reach_e", 3.0 * (reach - 1.0), Operation.ADD_VALUE);
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    /** Refresh attributes and sync stats. */
    public static void fullSync(ServerPlayer p) {
        refresh(p);
        save(p, get(p));
    }

    private static void mod(Player p, Holder<Attribute> attr, String name, double amount, Operation op) {
        AttributeInstance inst = p.getAttribute(attr);
        if (inst == null) return;
        ResourceLocation id = ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, name);
        inst.addOrUpdateTransientModifier(new AttributeModifier(id, amount, op));
    }
}
