package com.example.isekai.client;

import com.example.isekai.IsekaiMod;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import org.lwjgl.glfw.GLFW;

@EventBusSubscriber(modid = IsekaiMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    public static final KeyMapping OPEN_STATUS =
            new KeyMapping("key.isekai.status", GLFW.GLFW_KEY_K, "key.categories.isekai");

    public static final KeyMapping CAST_SKILL =
            new KeyMapping("key.isekai.cast", GLFW.GLFW_KEY_R, "key.categories.isekai");
    public static final KeyMapping NEXT_SKILL =
            new KeyMapping("key.isekai.next_skill", GLFW.GLFW_KEY_V, "key.categories.isekai");
    public static final KeyMapping PREV_SKILL =
            new KeyMapping("key.isekai.prev_skill", GLFW.GLFW_KEY_B, "key.categories.isekai");

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(OPEN_STATUS);
        e.register(CAST_SKILL);
        e.register(NEXT_SKILL);
        e.register(PREV_SKILL);
    }

    @SubscribeEvent
    public static void layers(RegisterGuiLayersEvent e) {
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "hud"), HudOverlay::render);
    }
}
