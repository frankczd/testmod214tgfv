package com.example.isekai;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: cast the selected skill. */
public record CastSkillPayload(String id) implements CustomPacketPayload {
    public static final Type<CastSkillPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "cast_skill"));

    public static final StreamCodec<ByteBuf, CastSkillPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.STRING_UTF8, CastSkillPayload::id, CastSkillPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
