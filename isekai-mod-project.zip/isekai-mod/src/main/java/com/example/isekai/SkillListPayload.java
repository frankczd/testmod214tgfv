package com.example.isekai;

import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: all skill definitions (names, costs, learning goals, evolution links). */
public record SkillListPayload(List<Entry> entries) implements CustomPacketPayload {
    public record Entry(String id, String name, String description, int tier, int maxLevel, int cost,
                        int learnAmount, int castMp, List<String> evolvesTo) {
        private static final StreamCodec<ByteBuf, String> S = ByteBufCodecs.STRING_UTF8;

        public static final StreamCodec<ByteBuf, Entry> CODEC = StreamCodec.of(
                (buf, e) -> {
                    S.encode(buf, e.id()); S.encode(buf, e.name()); S.encode(buf, e.description());
                    buf.writeInt(e.tier()); buf.writeInt(e.maxLevel()); buf.writeInt(e.cost());
                    buf.writeInt(e.learnAmount()); buf.writeInt(e.castMp());
                    buf.writeInt(e.evolvesTo().size());
                    for (String x : e.evolvesTo()) S.encode(buf, x);
                },
                buf -> {
                    String id = S.decode(buf);
                    String name = S.decode(buf);
                    String desc = S.decode(buf);
                    int tier = buf.readInt(), max = buf.readInt(), cost = buf.readInt(), learn = buf.readInt(), castMp = buf.readInt();
                    int n = buf.readInt();
                    List<String> ev = new ArrayList<>();
                    for (int i = 0; i < n; i++) ev.add(S.decode(buf));
                    return new Entry(id, name, desc, tier, max, cost, learn, castMp, ev);
                });
    }

    public static final Type<SkillListPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "skill_list"));

    public static final StreamCodec<ByteBuf, SkillListPayload> CODEC = StreamCodec.composite(
            Entry.CODEC.apply(ByteBufCodecs.list()), SkillListPayload::entries, SkillListPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
