package com.example.isekai;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: spend one stat point on stat index 0-4. */
public record AllocatePointPayload(int stat) implements CustomPacketPayload {
    public static final Type<AllocatePointPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "allocate_point"));

    public static final StreamCodec<ByteBuf, AllocatePointPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, AllocatePointPayload::stat, AllocatePointPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
