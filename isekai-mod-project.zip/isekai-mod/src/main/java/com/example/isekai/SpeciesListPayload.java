package com.example.isekai;

import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: every species, so the client can show names, start options and evolutions. */
public record SpeciesListPayload(List<Entry> entries) implements CustomPacketPayload {
    public record Entry(String id, String name, String description, boolean start, int maxLevel,
                        List<String> evolvesTo) {
        public static final StreamCodec<ByteBuf, Entry> CODEC = StreamCodec.composite(
                ByteBufCodecs.STRING_UTF8, Entry::id,
                ByteBufCodecs.STRING_UTF8, Entry::name,
                ByteBufCodecs.STRING_UTF8, Entry::description,
                ByteBufCodecs.BOOL, Entry::start,
                ByteBufCodecs.VAR_INT, Entry::maxLevel,
                ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list()), Entry::evolvesTo,
                Entry::new);
    }

    public static final Type<SpeciesListPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(IsekaiMod.MODID, "species_list"));

    public static final StreamCodec<ByteBuf, SpeciesListPayload> CODEC = StreamCodec.composite(
            Entry.CODEC.apply(ByteBufCodecs.list()), SpeciesListPayload::entries, SpeciesListPayload::new);

    public static SpeciesListPayload fromManager() { return SpeciesManager.listPayload(); }

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
