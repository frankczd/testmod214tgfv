package com.example.isekai;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Client-side skill data. No Minecraft client imports. */
public final class ClientSkills {
    private static Map<String, SkillState> owned = new LinkedHashMap<>();
    private static List<SkillListPayload.Entry> defs = new ArrayList<>();
    private static int version = 0;
    private ClientSkills() {}

    public static Map<String, SkillState> owned() { return owned; }
    public static List<SkillListPayload.Entry> defs() { return defs; }
    public static int version() { return version; }
    public static void setOwned(Map<String, SkillState> m) { owned = new LinkedHashMap<>(m); version++; }
    public static void setDefs(List<SkillListPayload.Entry> l) { defs = new ArrayList<>(l); version++; }

    public static SkillListPayload.Entry def(String id) {
        for (SkillListPayload.Entry d : defs) if (d.id().equals(id)) return d;
        return null;
    }

    public static boolean owns(String id) {
        SkillState st = owned.get(id);
        return st != null && st.level() >= 1;
    }

    public static boolean ownsDescendant(String id) {
        SkillListPayload.Entry d = def(id);
        if (d == null) return false;
        for (String n : d.evolvesTo()) if (owns(n) || ownsDescendant(n)) return true;
        return false;
    }
}
