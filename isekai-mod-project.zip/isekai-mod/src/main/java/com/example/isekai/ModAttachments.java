package com.example.isekai;

import java.util.function.Supplier;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

public class ModAttachments {
    public static final DeferredRegister<AttachmentType<?>> ATTACHMENTS =
            DeferredRegister.create(NeoForgeRegistries.ATTACHMENT_TYPES, IsekaiMod.MODID);

    /** Per-player RPG data. Saved with the player and copied on death. */
    public static final Supplier<AttachmentType<PlayerStats>> STATS = ATTACHMENTS.register("stats",
            () -> AttachmentType.builder(() -> PlayerStats.DEFAULT)
                    .serialize(PlayerStats.CODEC)
                    .copyOnDeath()
                    .build());

    /** Per-player skills. Saved with the player and copied on death. */
    public static final Supplier<AttachmentType<PlayerSkills>> SKILLS = ATTACHMENTS.register("skills",
            () -> AttachmentType.builder(() -> PlayerSkills.EMPTY)
                    .serialize(PlayerSkills.CODEC)
                    .copyOnDeath()
                    .build());
}
