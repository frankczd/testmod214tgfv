#!/bin/sh
./gradlew build && echo "Done. Your mod jar is in build/libs/ (use the one without -sources)"
