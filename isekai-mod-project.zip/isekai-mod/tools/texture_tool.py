#!/usr/bin/env python3
"""
Isekai texture tool. Turns downloaded icons, generated shapes, or AI images
into Minecraft-ready pixel textures (+ item model JSON).

  python texture_tool.py fetch lorc/fangs              # grab a game-icons.net SVG
  python texture_tool.py build manifest.json           # convert everything in a manifest
  python texture_tool.py gen gem ruby_shard --color "#d02040"
  python texture_tool.py ai "green spider fang, pixel art" poison_fang
"""
import argparse, base64, io, json, os, sys, urllib.request
from pathlib import Path
from PIL import Image, ImageDraw, ImageOps

MODID = "isekai"
ASSETS = Path("../src/main/resources/assets") / MODID


def hex_rgb(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def finish(img, size=16, colors=16):
    """Downscale, quantize palette, hard alpha edges = pixel-art look."""
    img = img.convert("RGBA")
    img = img.resize((size, size), Image.LANCZOS)
    alpha = img.getchannel("A").point(lambda v: 255 if v >= 128 else 0)
    rgb = img.convert("RGB").quantize(colors=colors, method=Image.Quantize.MEDIANCUT).convert("RGB")
    out = rgb.convert("RGBA")
    out.putalpha(alpha)
    return out


def load_source(path, tint=None):
    path = Path(path)
    if path.suffix.lower() == ".svg":
        try:
            import cairosvg
        except ImportError:
            sys.exit("SVG needs cairosvg:  pip install cairosvg")
        img = Image.open(io.BytesIO(cairosvg.svg2png(url=str(path), output_width=512, output_height=512)))
    else:
        img = Image.open(path)
    img = img.convert("RGBA")
    if tint:
        # game-icons style (white shape on black): brightness becomes opacity, then recolor
        lum = ImageOps.grayscale(img.convert("RGB"))
        solid = Image.new("RGBA", img.size, hex_rgb(tint) + (255,))
        solid.putalpha(lum)
        img = solid
    return img


def write(name, img, assets, model=True):
    tex = assets / "textures" / "item"
    tex.mkdir(parents=True, exist_ok=True)
    img.save(tex / f"{name}.png")
    if model:
        m = assets / "models" / "item"
        m.mkdir(parents=True, exist_ok=True)
        (m / f"{name}.json").write_text(json.dumps(
            {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MODID}:item/{name}"}}, indent=2))
    print("wrote", tex / f"{name}.png")


# ---------- procedural placeholders ----------
def draw_shape(kind, color):
    S = 16
    c = hex_rgb(color)
    dark = tuple(int(v * 0.55) for v in c)
    light = tuple(min(255, int(v * 1.4) + 30) for v in c)
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    if kind == "gem":
        d.polygon([(8, 1), (14, 6), (8, 15), (2, 6)], fill=c + (255,), outline=dark + (255,))
        d.polygon([(8, 1), (11, 6), (8, 6), (5, 6)], fill=light + (255,))
    elif kind == "orb":
        d.ellipse([2, 2, 13, 13], fill=c + (255,), outline=dark + (255,))
        d.ellipse([4, 4, 7, 7], fill=light + (255,))
    elif kind == "blade":
        d.line([(3, 13), (13, 3)], fill=c + (255,), width=2)
        d.line([(2, 10), (6, 14)], fill=dark + (255,), width=2)   # guard
        d.line([(1, 15), (3, 13)], fill=(110, 70, 30, 255), width=2)  # grip
        d.point([(12, 3), (13, 4)], fill=light + (255,))
    else:
        sys.exit(f"unknown kind '{kind}' (gem, orb, blade)")
    return im


# ---------- AI image API (OpenAI-compatible /images/generations) ----------
def ai_image(prompt):
    url = os.environ.get("IMAGE_API_URL", "https://api.openai.com/v1/images/generations")
    key = os.environ.get("IMAGE_API_KEY") or sys.exit("Set IMAGE_API_KEY (and optionally IMAGE_API_URL, IMAGE_MODEL)")
    body = {"model": os.environ.get("IMAGE_MODEL", "gpt-image-1"),
            "prompt": prompt + ", single game item icon, centered, plain flat background, no text",
            "size": "1024x1024", "n": 1}
    req = urllib.request.Request(url, json.dumps(body).encode(),
                                 {"Content-Type": "application/json", "Authorization": f"Bearer {key}"})
    data = json.load(urllib.request.urlopen(req, timeout=120))["data"][0]
    if "b64_json" in data:
        raw = base64.b64decode(data["b64_json"])
    else:
        raw = urllib.request.urlopen(data["url"], timeout=60).read()
    return Image.open(io.BytesIO(raw)).convert("RGBA")


def strip_background(img, tol=40):
    """Make everything close to the corner color transparent."""
    bg = img.getpixel((0, 0))[:3]
    px = img.load()
    for y in range(img.height):
        for x in range(img.width):
            r, g, b, _ = px[x, y]
            if abs(r - bg[0]) + abs(g - bg[1]) + abs(b - bg[2]) < tol * 3 // 2:
                px[x, y] = (0, 0, 0, 0)
    return img


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--assets", default=str(ASSETS), help="assets/<modid> folder")
    ap.add_argument("--size", type=int, default=16)
    ap.add_argument("--colors", type=int, default=16)
    ap.add_argument("--no-model", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)

    f = sub.add_parser("fetch"); f.add_argument("icon", help="author/name from game-icons.net, e.g. lorc/fangs")
    b = sub.add_parser("build"); b.add_argument("manifest")
    g = sub.add_parser("gen"); g.add_argument("kind"); g.add_argument("name"); g.add_argument("--color", default="#8040c0")
    a = sub.add_parser("ai"); a.add_argument("prompt"); a.add_argument("name")
    args = ap.parse_args()
    assets = Path(args.assets)
    model = not args.no_model

    if args.cmd == "fetch":
        url = f"https://raw.githubusercontent.com/game-icons/icons/master/{args.icon}.svg"
        dest = Path("packs") / f"{args.icon}.svg"
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(urllib.request.urlopen(url, timeout=30).read())
        print("saved", dest, "- add it to your manifest (CC BY 3.0, credit the author)")
    elif args.cmd == "build":
        m = json.loads(Path(args.manifest).read_text())
        size, colors = m.get("size", args.size), m.get("colors", args.colors)
        base = Path(args.manifest).parent
        for name, e in m["icons"].items():
            img = load_source(base / e["src"], e.get("tint"))
            write(name, finish(img, e.get("size", size), colors), assets, model)
    elif args.cmd == "gen":
        write(args.name, draw_shape(args.kind, args.color), assets, model)
    elif args.cmd == "ai":
        img = strip_background(ai_image(args.prompt))
        write(args.name, finish(img, args.size, args.colors), assets, model)


if __name__ == "__main__":
    main()
