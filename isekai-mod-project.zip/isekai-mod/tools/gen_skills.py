#!/usr/bin/env python3
"""
Generates every canon skill as JSON in src/main/resources/data/isekai/skills/ plus SKILLS.md.
Names, categories and tier chains come from the So I'm a Spider, So What? wiki skill list.
Run from the project root:  python tools/gen_skills.py
"functional" skills do something in the mod; "catalog" skills exist (grantable, listed) but their
effect is not built yet. Numbers marked ESTIMATE are guesses, the wiki doesn't give them.
"""
import json, os, re, shutil

OUT = "src/main/resources/data/isekai/skills"
skills, cats = {}, {}

def slug(n):
    return re.sub(r"[^a-z0-9]+", "_", n.lower().replace("'", "")).strip("_")

def put(cat, name, tier, evolves=None, impl=None, canon=""):
    sid = slug(name)
    d = {"name": name, "tier": tier, "max_level": 10, "evolves_to": evolves or []}
    extra = impl(tier - 1) if impl else None
    if extra:
        d.update({k: v for k, v in extra.items() if k != "desc"})
        d["description"] = extra["desc"]
        d["_status"] = "functional"
    else:
        d["description"] = f"{cat} skill, tier {tier}. In the canon skill list; its effect is not built yet."
        d["_status"] = "catalog"
    if canon and "_canon" not in d:
        d["_canon"] = canon
    skills[sid] = d
    cats.setdefault(cat, []).append(sid)
    return sid

def chain(cat, names, impl=None, canon="", skip_link=False):
    ids = [slug(n) for n in names]
    for i, n in enumerate(names):
        put(cat, n, i + 1, [ids[i + 1]] if i + 1 < len(names) and not skip_link else [], impl, canon)

def single(cat, name, impl=None, canon="", tier=1, evolves=None):
    put(cat, name, tier, evolves, impl, canon)

# ============================ STAT & ABILITY ============================
def statchain(stat, label, flats, growths, train, learn=None, cost=0, hint="", canon=""):
    def impl(i):
        d = {"stat": stat, "flat_per_level": flats[i], "growth_per_level": growths[i], "train_on": train,
             "desc": f"Adds +{flats[i]:g} {label} per skill level, and +{growths[i]:g} per skill level for every character level."}
        if i == 0:
            if learn:
                d["learn_on"], d["learn_amount"] = learn
            if cost:
                d["cost"] = cost
            if hint:
                d["desc"] += " " + hint
        if canon:
            d["_canon"] = canon
        return d
    return impl

EST = "Per-tier x1 / x10 / x100 pattern from the wiki; growth, cost and learning amounts are ESTIMATES."
chain("Stat & Ability", ["Strength", "Herculean Strength", "Fortitude"],
      statchain("offense", "Offense", [1, 10, 100], [0.1, 1, 10], "deal_damage", ("deal_damage", 100), 20,
                "Learned after landing 100 hits, or bought with skill points.",
                "Strength and Herculean Strength effects verified; Fortitude x100 assumed. " + EST))
chain("Stat & Ability", ["Solidity", "Sturdy", "Stronghold"],
      statchain("defense", "Defense", [1, 10, 100], [0.1, 1, 10], "take_damage", ("take_damage", 100), 20,
                "Learned after taking 100 hits, or bought with skill points.",
                "Solidity verified; Sturdy/Stronghold assumed from the pattern. " + EST))
chain("Stat & Ability", ["Running", "Acceleration", "Skanda"],
      statchain("speed", "Speed", [1, 10, 100], [0.1, 1, 10], "sprint", ("sprint", 120), 20,
                "Learned after sprinting for 2 minutes in total, or bought with skill points.",
                "Skanda +100 per level verified (+10 growth from a secondary wiki). " + EST))
chain("Stat & Ability", ["Life", "Longevity", "Ultimate Life"],
      statchain("hp", "HP", [1, 10, 100], [0.1, 1, 10], "take_damage", None, 0,
                "Awarded by a title in canon, so it can't be obtained yet.",
                "Verified: +level / x10 / x100 HP. Titles aren't built yet."))
chain("Stat & Ability", ["Magic Mass", "Magic Hoard", "Ultimate Magic", "Celestial Power"],
      lambda i: None if i == 3 else statchain("mp", "MP", [1, 10, 100], [0.1, 1, 10], "mp_recover", ("mp_recover", 150), 20,
                "Learned after 2.5 minutes with low MP, or bought with skill points.",
                "Skill chain verified; that it raises MP is ASSUMED. " + EST)(i))
chain("Stat & Ability", ["Protection", "Talisman", "Sanctum"],
      statchain("resistance", "Resistance", [1, 10, 100], [0.1, 1, 10], "take_damage", ("take_damage", 200), 20,
                "Learned after taking 200 hits, or bought with skill points.",
                "Skill chain verified; that it raises Resistance is ASSUMED. " + EST))

def regen(hp, per, train, learn, cost, hint):
    def impl(i):
        d = {("hp_regen_pct" if hp else "mp_regen_pct"): per[i], "train_on": train,
             "desc": f"Recovers {per[i]:g}% of max {'HP' if hp else 'MP'} per second per skill level."}
        if i == 0:
            d["learn_on"], d["learn_amount"] = learn
            d["cost"] = cost
            d["desc"] += " " + hint
        d["_canon"] = "Tier names verified; recovery rates are ESTIMATES."
        return d
    return impl
chain("Stat & Ability", ["HP Auto-Recovery", "HP Rapid Recovery", "HP Ultra-Fast Recovery"],
      regen(True, [0.1, 0.3, 0.8], "recover", ("wounded", 120), 15, "Learned after 2 minutes of being wounded, or bought with skill points."))
chain("Stat & Ability", ["MP Recovery Speed", "MP Rapid Recovery", "Height of Occultism"],
      regen(False, [0.2, 0.6, 1.5], "mp_recover", ("mp_recover", 150), 15, "Learned after 2.5 minutes with low MP, or bought with skill points."))
chain("Stat & Ability", ["MP Lessened Consumption", "MP Minimized Consumption"])
chain("Stat & Ability", ["SP Recovery Speed", "SP Rapid Recovery"])
chain("Stat & Ability", ["SP Lessened Consumption", "SP Minimized Consumption"])
chain("Stat & Ability", ["Persistent", "Endurance", "Fortune"])
chain("Stat & Ability", ["Instantaneous", "Instant Body", "Ultimate Movement"])
chain("Stat & Ability", ["Technique User", "Monk", "Deva"])

# ============================ ATTACK ============================
def attack(effect, secs, dmg):
    def impl(i):
        name = {"fire": "ablaze", "freeze": "frozen", "poison": "poisoned", "slowness": "slowed", "weakness": "weakened", "wither": "withered"}.get(effect, "")
        d = {"train_on": "melee_hit", "fx": {"hit_damage": dmg[i]},
             "desc": f"Adds {dmg[i]:g} bonus damage per skill level to your melee hits."}
        if effect:
            d["fx"].update({"hit_effect": effect, "hit_seconds": secs * (1 if i == 0 else 2)})
            d["desc"] += f" Leaves targets {name} for {secs * (1 if i == 0 else 2):g}s per skill level."
        if i == 0:
            d["cost"] = 30
            d["desc"] += " Buy with skill points."
        d["_canon"] = "Skill names and tiers verified; damage numbers and the way it applies in Minecraft are ESTIMATES."
        return d
    return impl
for names, eff, secs, dmg in [
    (["Energy Attack", "Energy Super-Attack"], "", 0, (0.3, 1.5)),
    (["Magic Power Attack", "Magic Power Super-Attack"], "", 0, (0.3, 1.5)),
    (["Fire Attack", "Flame Attack"], "fire", 1, (0.3, 1.5)),
    (["Lightning Attack", "Bolt Attack"], "", 0, (0.3, 1.5)),
    (["Water Attack", "Flood Attack"], "", 0, (0.3, 1.5)),
    (["Ice Attack", "Freeze Attack"], "freeze", 1, (0.2, 1.0)),
    (["Wind Attack", "Gale Attack"], "", 0, (0.3, 1.5)),
    (["Earth Attack", "Terrain Attack"], "", 0, (0.3, 1.5)),
    (["Light Attack", "Holy Light Attack"], "", 0, (0.3, 1.5)),
    (["Dark Attack", "Black Attack"], "", 0, (0.3, 1.5)),
    (["Poison Attack", "Deadly Poison Attack"], "poison", 1, (0.2, 1.0)),
    (["Acid Attack", "Strong Acid Attack"], "weakness", 1, (0.3, 1.5)),
    (["Paralysis Attack", "Enhanced Paralysis Attack"], "slowness", 1, (0.1, 0.5)),
    (["Heavy Attack", "Heavy Super-Attack"], "slowness", 0.5, (0.3, 1.5)),
    (["Rot Attack"], "wither", 0.5, (0.3, 1.5)),
    (["Heretic Attack"], "", 0, (0.4, 2.0))]:
    chain("Attack", names, attack(eff, secs, dmg))

# ============================ ENHANCEMENT ============================
def phys_enh(i):
    d = {"train_on": "melee_hit", "fx": {"hit_damage": [0.15, 0.75][i]},
         "desc": f"Adds {[0.15, 0.75][i]:g} bonus damage per skill level to your melee hits."}
    if i == 0:
        d["cost"] = 25
        d["desc"] += " Buy with skill points."
    d["_canon"] = "Names and tiers verified; effect numbers are ESTIMATES."
    return d
for n in ["Destruction", "Cutting", "Piercing", "Impact"]:
    chain("Enhancement", [f"{n} Enhancement", f"{n} Super-Enhancement"], phys_enh)
chain("Enhancement", ["Shock Enhancement", "Shock Super-Enhancement"])
chain("Enhancement", ["Paralysis Enhancement", "Paralysis Super-Enhancement", "Status Condition Super-Enhancement"])
for n in ["Petrification", "Poison", "Exhaustion"]:
    chain("Enhancement", [f"{n} Enhancement", f"{n} Super-Enhancement"])
for a, b in [("Acid Enhancement", "Strong Acid Enhancement"), ("Fire Enhancement", "Flame Enhancement"),
             ("Lightning Enhancement", "Bolt Enhancement"), ("Water Enhancement", "Flood Enhancement"),
             ("Ice Enhancement", "Freeze Enhancement"), ("Wind Enhancement", "Gale Enhancement"),
             ("Earth Enhancement", "Terrain Enhancement"), ("Light Enhancement", "Holy Light Enhancement"),
             ("Dark Enhancement", "Black Enhancement"), ("Heavy Enhancement", "Heavy Super-Enhancement")]:
    chain("Enhancement", [a, b])

# ============================ ACTIVE ============================
single("Active", "Poison Fang", lambda i: {
    "train_on": "poison_fang_hit", "train_xp": 2,
    "desc": "Your melee hits poison the target. Duration grows with skill level, and the poison is stronger from Lv 7.",
    "_canon": "Starting skill of the Taratect line (verified). Effect numbers are ESTIMATES."}, evolves=["poison_attack"])
for n in ["Poison Sting", "Poison Claw", "Magic Power Conferment", "Magic Conferment", "Energy Conferment",
          "Ability Conferment", "Poison Synthesis", "Medicine Synthesis", "Cutting Thread", "Thread Control",
          "Iron Defense"]:
    single("Active", n)
chain("Active", ["Magic Warfare", "Magic Divinity"])
chain("Active", ["Mental Warfare", "Battle Divinity"])
chain("Active", ["Wyrm Power", "Dragon Power", "Divine Dragon Power"])
chain("Active", ["Wyrm Barrier", "Dragon Barrier", "Divine Dragon Barrier"])
chain("Active", ["Telekinesis", "Psychokinesis"])
chain("Active", ["Spider Thread", "Utility Thread", "Divine Thread Weaving"],
      canon="Spider Thread is a starting skill of the Taratect line (verified). Thread shooting comes in a later build.")
chain("Active", ["Spatial Maneuvering", "Dimensional Maneuvering"])
chain("Active", ["Curse", "Jinx"])
chain("Active", ["Undying Body", "Undying Commander", "Undying King"])
chain("Active", ["Telescopic Sight", "Clairvoyance", "Panoptic Vision"])

# ============================ LEADERSHIP ============================
chain("Leadership", ["Leadership", "Command", "Tactician"])
chain("Leadership", ["Telepathy", "Fartalk"])
chain("Leadership", ["Creature Training", "Summoning"])
single("Leadership", "Kin Control")

# ============================ PERCEPTION ============================
single("Perception", "Appraisal", evolves=["wisdom"], canon="Reads information about creatures and objects. Integrated into Wisdom.")
for n in ["Magic Power Perception", "Technique Perception", "Material Perception", "Presence Perception",
          "Danger Perception", "Motion Perception", "Heat Perception", "Reaction Perception", "Space Perception"]:
    single("Perception", n, evolves=["detection"])
single("Perception", "Detection", tier=2, evolves=["wisdom"])
single("Perception", "Concentration", evolves=["thought_acceleration"])
chain("Perception", ["Thought Acceleration", "Thought Super-Acceleration"])
chain("Perception", ["Prediction", "Foresight", "Future Sight"])
chain("Perception", ["Parallel Thinking", "Parallel Minds"])
chain("Perception", ["Arithmetic Processing", "High-Speed Processing"])
chain("Perception", ["Memory", "Record"])

# ============================ MAGIC ============================
chain("Magic", ["Magic Power Operation", "Precise Magic Power Operation"])
for tri in [("Fire Magic", "Flame Magic", "Inferno Magic"), ("Lightning Magic", "Bolt Magic", "Thunder Magic"),
            ("Water Magic", "Flood Magic", "Tide Magic"), ("Ice Magic", "Freeze Magic", "Glacial Magic"),
            ("Wind Magic", "Gale Magic", "Tempest Magic"), ("Earth Magic", "Terrain Magic", "Seismic Magic"),
            ("Shadow Magic", "Dark Magic", "Black Magic")]:
    chain("Magic", list(tri))
chain("Magic", ["Light Magic", "Holy Light Magic"])
chain("Magic", ["Spatial Magic", "Dimensional Magic"])
for n in ["Heavy Magic", "Heretic Magic", "Poison Magic", "Healing Magic", "Miracle Magic", "Abyss Magic"]:
    single("Magic", n)
chain("Evil Eyes", ["Cursed Evil Eye", "Jinx Evil Eye"])
chain("Evil Eyes", ["Paralyzing Evil Eye", "Inert Evil Eye"])
chain("Evil Eyes", ["Heavy Evil Eye", "Repellent Evil Eye"])
for n in ["Annihilating Evil Eye", "Petrifying Evil Eye", "Warped Evil Eye", "Discomforting Evil Eye",
          "Phantom Pain Evil Eye", "Maddening Evil Eye", "Charming Evil Eye", "Hypnotizing Evil Eye", "Fearful Evil Eye"]:
    single("Evil Eyes", n)

# ============================ RESISTANCE ============================
PCT = [3, 6.5, 10]  # percent absorbed per skill level, tiers 1-3 (so Lv10 = 30% / 65% / 100%)
def resist(cats_, label, learn, amount, tiername):
    def impl(i):
        d = {"train_on": learn, "fx": {"resist": cats_, "resist_pct": PCT[i]},
             "desc": f"Absorbs {PCT[i]:g}% of {label} damage per skill level."}
        if i == 0:
            d["learn_on"], d["learn_amount"] = learn, amount
            d["desc"] += f" Learned by taking {amount} hits of this kind of damage."
        d["_canon"] = "Skill names and tiers verified. How it maps to Minecraft damage, and the percentages, are ESTIMATES."
        return d
    return impl
R = [  # names, categories, label, learn trigger, amount
    (["Destruction Resistance", "Destruction Super-Resistance", "Physical Nullification"], ["physical", "projectile", "impact", "blast"], "physical", "take_damage", 300),
    (["Impact Resistance", "Impact Super-Resistance"], ["impact"], "fall and impact", "dmg_impact", 40),
    (["Cutting Resistance", "Cutting Super-Resistance"], ["physical"], "melee", "dmg_physical", 80),
    (["Piercing Resistance", "Piercing Super-Resistance"], ["projectile"], "projectile", "dmg_projectile", 60),
    (["Shock Resistance", "Shock Super-Resistance"], ["blast"], "explosion", "dmg_blast", 30),
    (["Poison Resistance", "Deadly Poison Resistance", "Status Condition Nullification"], ["magic"], "poison and magic", "dmg_magic", 40),
    (["Fire Resistance", "Flame Resistance", "Heat Nullification"], ["fire"], "fire", "dmg_fire", 40),
    (["Water Resistance", "Flood Resistance", "Flood Nullification"], ["drown"], "drowning", "dmg_drown", 20),
    (["Ice Resistance", "Freeze Resistance", "Freeze Nullification"], ["freeze"], "freezing", "dmg_freeze", 25),
    (["Lightning Resistance", "Bolt Resistance", "Bolt Nullification"], ["lightning"], "lightning", "dmg_lightning", 3),
    (["Earth Resistance", "Terrain Resistance", "Terrain Nullification"], ["earth"], "suffocation and cramming", "dmg_earth", 40),
    (["Rot Resistance", "Rot Super-Resistance", "Rot Nullification"], ["wither"], "wither", "dmg_wither", 25),
]
for names, c, label, trig, amt in R:
    chain("Resistance", names, resist(c, label, trig, amt, ""))
for tri in [("Paralysis Resistance", "Paralysis Super-Resistance"), ("Petrification Resistance", "Petrification Super-Resistance"),
            ("Exhaustion Resistance", "Exhaustion Super-Resistance", "Exhaustion Nullification"),
            ("Status Condition Resistance", "Status Condition Super-Resistance"),
            ("Faint Resistance", "Faint Super-Resistance", "Faint Nullification"),
            ("Fear Resistance", "Fear Super-Resistance", "Fear Nullification"),
            ("Wind Resistance", "Gale Resistance", "Gale Nullification"),
            ("Light Resistance", "Holy Light Resistance", "Holy Light Nullification"),
            ("Dark Resistance", "Black Resistance", "Black Nullification"),
            ("Heavy Resistance", "Heavy Super-Resistance", "Heavy Nullification"),
            ("Acid Resistance", "Acid Super-Resistance", "Acid Nullification"),
            ("Heresy Resistance", "Heresy Super-Resistance", "Heresy Nullification"),
            ("Pain Resistance", "Pain Nullification"),
            ("Pain Mitigation", "Pain Super-Mitigation", "Suffering Nullification")]:
    chain("Resistance", list(tri))

# ============================ PASSIVE ============================
chain("Passive", ["Night Vision", "Vision Expansion", "Perception Expansion"],
      lambda i: {"fx": {"passive": "night_vision"}, "desc": "See in the dark while you own this skill."} if i == 0 else None,
      canon="Night Vision is a starting skill of the Taratect line (verified); Vision Expansion is derived from it.")
chain("Passive", ["Vision Enhancement", "Five Senses Enhancement", "Five Senses Super-Enhancement"])
for n in ["Auditory Enhancement", "Olfactory Enhancement", "Tactile Enhancement", "Taste Enhancement"]:
    single("Passive", n, evolves=["five_senses_enhancement"])
chain("Passive", ["Throw", "Expel"])
single("Passive", "Hit", evolves=["probability_correction"])
chain("Passive", ["Probability Correction", "Probability Super-Correction"])
chain("Passive", ["Camouflage", "Concealment"])
single("Passive", "Auditory Expansion")
for tri in [("Dragon Scales", "Imperial Scales", "Divine Scales"), ("Shell", "Hard Armor", "Heavy Armor"),
            ("Ore Body", "Steel Body", "Ultra Steel Body"), ("Intimidation", "Tyrant", "Emperor"),
            ("Swordsmanship", "Sword Mastery", "Sword Hero")]:
    chain("Passive", list(tri))
chain("Passive", ["Flight", "High-Speed Flight"])
chain("Passive", ["Swimming", "High-Speed Swimming"])
chain("Passive", ["Threadsmanship", "Thread Genius"])
chain("Passive", ["Athletics", "Martial Arts Mastery"])

# ============================ OTHER ============================
for tri in [("Desire", "Dignity", "Pride"), ("Rest", "Indolence", "Sloth"), ("Overeating", "Satiation", "Gluttony"),
            ("Anger", "Rage", "Wrath"), ("Spite", "Jealousy", "Envy"), ("Snatch", "Usurp", "Greed"),
            ("Crude", "Depraved", "Lust"), ("Supplication", "Prayer", "Humility")]:
    chain("Ruler (Seven Sins and Virtues)", list(tri), canon="Part of the Ruler skill lines. Usually tied to titles.")
single("Other", "Root of Evil")
chain("Other", ["Demon Lord", "Great Demon Lord"], lambda i: {
    "stat": "all", "flat_per_level": [100, 1000][i], "growth_per_level": 0,
    "desc": f"Adds +{[100, 1000][i]} to every main stat per skill level.",
    "_canon": "Demon Lord +100 per level to every stat is verified; Great Demon Lord x10 is ASSUMED. Needs titles, so not obtainable yet."})
single("Other", "Hero", impl=lambda i: {"stat": "all", "flat_per_level": 100, "growth_per_level": 0,
    "desc": "Adds +100 to every main stat per skill level.",
    "_canon": "Verified: +100 per level to every stat. Needs titles, so not obtainable yet."})
for el in ["Fire", "Earth", "Water", "Wind", "Light", "Dark"]:
    chain("Other", [f"{el} Wyrm", f"{el} Dragon"])
chain("Other", ["Vampire", "Higher Vampire"])
for n in ["Skill Elimination", "Student Roster", "Book Lover", "Infinite Calling", "Tears Shed", "Dungeon Creation",
          "Weapon Creation", "Instant Response", "Divine Protection", "Lazy Efficiency", "Sweets Girl",
          "Animal Friend", "Trend Leader", "Divinity Expansion", "Wisdom", "Taboo", "n%I = W", "Egg-Laying",
          "Perseverance", "Hades", "Corruption", "Sublimation", "Enma", "Conquest", "Stupefaction", "Immortality"]:
    single("Other", n)

# ============================ UPGRADE LAYER: make more skills do something ============================
# Everything below is a design choice, not wiki data. Names and tiers are canon; effects and numbers are ESTIMATES.
UPCANON = "Name and tier verified from the wiki. What it does here, and every number, are ESTIMATES (the wiki gives no figures)."

def castfx(kind, mp, cd=1.0, rng=20, power=0.0, ppl=0.0, effect="", secs=0.0, spl=0.0, amp=0):
    return {"cast": {"kind": kind, "mp": mp, "cooldown": cd, "range": rng, "power": power, "power_per_level": ppl,
                     "effect": effect, "seconds": secs, "seconds_per_level": spl, "amp": amp}}

def up(name, desc, fx=None, cost=0, train="", stat=None, flat=0, growth=0, **extra):
    sid = slug(name)
    d = skills[sid]                       # KeyError here means a typo, which is what we want
    d["_status"], d["description"], d["_canon"] = "functional", desc, UPCANON
    if fx:
        d["fx"] = {**d.get("fx", {}), **fx}
    if fx and "cast" in fx and not train:
        train = "cast_" + sid             # casting a skill levels it
    if train:
        d["train_on"] = train
    if cost:
        d["cost"] = cost
    if stat:
        d["stat"], d["flat_per_level"], d["growth_per_level"] = stat, flat, growth
    d.update(extra)

# ---- Elemental and other magic (bolts aimed at what you're looking at) ----
BASE, PER, MPC, CD, RNG, SECS = (2, 10, 40), (1, 3, 10), (6, 15, 40), (1, 2, 4), (24, 28, 32), (3, 4, 5)
for names, eff in [(("Fire Magic", "Flame Magic", "Inferno Magic"), "fire"),
                   (("Lightning Magic", "Bolt Magic", "Thunder Magic"), "lightning"),
                   (("Water Magic", "Flood Magic", "Tide Magic"), "knockback"),
                   (("Ice Magic", "Freeze Magic", "Glacial Magic"), "freeze"),
                   (("Wind Magic", "Gale Magic", "Tempest Magic"), "launch"),
                   (("Earth Magic", "Terrain Magic", "Seismic Magic"), "slowness"),
                   (("Shadow Magic", "Dark Magic", "Black Magic"), "darkness"),
                   (("Light Magic", "Holy Light Magic"), "glow")]:
    for i, n in enumerate(names):
        amp = i + 1 if eff in ("knockback", "launch", "slowness") else 0
        up(n, f"Cast a bolt ({eff}) at what you aim at: {BASE[i]} + {PER[i]} per skill level damage, boosted by your Magic. Costs {MPC[i]} MP.",
           castfx("bolt", MPC[i], CD[i], RNG[i], BASE[i], PER[i], eff, SECS[i], 0, amp), cost=40 if i == 0 else 0)
up("Heavy Magic", "Cast a crushing bolt that damages and heavily slows the target. 12 MP.", castfx("bolt", 12, 2, 24, 3, 1.5, "slowness", 4, 0, 2), cost=40)
up("Heretic Magic", "Cast a bolt that damages and withers the target. 15 MP.", castfx("bolt", 15, 2, 24, 3, 1.5, "wither", 4), cost=40)
up("Poison Magic", "Cast a bolt that damages and poisons the target. 10 MP.", castfx("bolt", 10, 1.5, 24, 2, 1, "poison", 5), cost=40)
up("Healing Magic", "Heal yourself for 4 + 2 per skill level (boosted by Magic). 10 MP.", castfx("heal", 10, 2, 0, 4, 2), cost=40)
up("Miracle Magic", "Heal yourself for 10 + 4 per skill level and gain regeneration. 30 MP.", castfx("heal", 30, 6, 0, 10, 4, "regeneration", 8, 0, 1), cost=80)
up("Spatial Magic", "Blink up to 12 blocks in the direction you are looking. 12 MP.", castfx("dash", 12, 3, 12), cost=60)
up("Dimensional Magic", "Blink up to 40 blocks in the direction you are looking. 30 MP.", castfx("dash", 30, 5, 40))
up("Abyss Magic", "A devastating bolt: 20 + 6 per skill level, withering and darkening the target. 50 MP.", castfx("bolt", 50, 5, 28, 20, 6, "wither,darkness", 6, 0, 1), cost=0)
up("Magic Power Operation", "Boosts the damage and healing of all your spells by 3% per skill level.", {"passive": "magic_power", "passive_power": 3}, cost=40, train="alive")
up("Precise Magic Power Operation", "Boosts the damage and healing of all your spells by 6% per skill level.", {"passive": "magic_power", "passive_power": 6}, train="alive")
up("Arithmetic Processing", "Boosts spell power by 1% per skill level.", {"passive": "magic_power", "passive_power": 1}, cost=30, train="alive")
up("High-Speed Processing", "Boosts spell power by 2% per skill level.", {"passive": "magic_power", "passive_power": 2}, train="alive")

# ---- Evil Eyes: look at a target and cast ----
EYES = {"Cursed Evil Eye": ("weakness,wither", 6, 0, 0, 12), "Jinx Evil Eye": ("weakness,slowness", 8, 1, 0, 25),
        "Annihilating Evil Eye": ("wither", 5, 1, 15, 30), "Paralyzing Evil Eye": ("stun", 4, 0, 0, 14),
        "Inert Evil Eye": ("stun", 8, 0, 0, 28), "Petrifying Evil Eye": ("stun", 10, 0, 0, 25),
        "Heavy Evil Eye": ("slowness", 6, 3, 0, 12), "Repellent Evil Eye": ("knockback", 1, 3, 0, 20),
        "Warped Evil Eye": ("nausea,levitate", 5, 0, 0, 14), "Discomforting Evil Eye": ("nausea,slowness", 6, 1, 0, 12),
        "Phantom Pain Evil Eye": ("poison", 8, 1, 0, 14), "Maddening Evil Eye": ("nausea,weakness", 8, 0, 0, 16),
        "Charming Evil Eye": ("charm", 6, 0, 0, 14), "Hypnotizing Evil Eye": ("sleep", 6, 0, 0, 18),
        "Fearful Evil Eye": ("fear", 6, 0, 0, 14)}
for n, (eff, secs, amp, dmg, mp) in EYES.items():
    t1 = skills[slug(n)]["tier"] == 1
    up(n, f"Gaze at a target to inflict {eff.replace(',', ' + ')} for about {secs}s." + (f" Also deals {dmg} damage." if dmg else "") + f" Costs {mp} MP.",
       castfx("bolt", mp, 3, 22, dmg, dmg / 5, eff, secs, 0.3, amp), cost=60 if t1 else 0)

# ---- Active skills ----
up("Poison Sting", "Short-range poison jab at a target: 2 + 1 per skill level damage and poison. 4 MP.", castfx("bolt", 4, 1, 5, 2, 1, "poison", 3), cost=35)
up("Poison Claw", "Your melee hits add poison and a little bonus damage.", {"hit_damage": 0.2, "hit_effect": "poison", "hit_seconds": 1}, cost=35, train="melee_hit")
up("Magic Power Conferment", "Grants you an absorption shield for 20s. 20 MP.", castfx("self", 20, 30, 0, 0, 0, "absorption", 20, 0, 1), cost=50)
up("Magic Conferment", "Grants you regeneration for 10s. 20 MP.", castfx("self", 20, 25, 0, 0, 0, "regeneration", 10, 0, 1), cost=50)
up("Energy Conferment", "Grants you damage resistance for 15s. 25 MP.", castfx("self", 25, 30, 0, 0, 0, "resistance", 15), cost=50)
up("Ability Conferment", "Grants you strength and speed for 15s. 25 MP.", castfx("self", 25, 30, 0, 0, 0, "strength,speed", 15), cost=50)
for i, n in enumerate(["Wyrm Power", "Dragon Power", "Divine Dragon Power"]):
    up(n, f"Surge with draconic power: strength and resistance (level {i + 1}) for 20s. {30 + 30 * i} MP.", castfx("self", 30 + 30 * i, 40, 0, 0, 0, "strength,resistance", 20, 0, i), cost=70 if i == 0 else 0)
for i, n in enumerate(["Wyrm Barrier", "Dragon Barrier", "Divine Dragon Barrier"]):
    up(n, f"Raise a barrier: a large absorption shield for 20s. {25 + 25 * i} MP.", castfx("self", 25 + 25 * i, 35, 0, 0, 0, "absorption", 20, 0, [2, 4, 7][i]), cost=70 if i == 0 else 0)
up("Telekinesis", "Pull a target toward you. 6 MP.", castfx("bolt", 6, 1.5, 16, 0, 0, "pull", 1, 0, 1), cost=40)
up("Psychokinesis", "Yank a target toward you and lift it briefly. 12 MP.", castfx("bolt", 12, 2, 24, 0, 0, "pull,levitate", 2, 0, 3))
up("Spider Thread", "Shoot a thread that webs a target (heavy slow for 4s). 5 MP.", castfx("bolt", 5, 1.5, 20, 0, 0, "slowness", 4, 0, 3), cost=0)
up("Utility Thread", "A stronger, longer thread: slows and weakens a target for 6s. 12 MP.", castfx("bolt", 12, 2, 28, 0, 0, "slowness,weakness", 6, 0, 5))
up("Divine Thread Weaving", "Bind a target completely for 8s and deal damage. 30 MP.", castfx("bolt", 30, 4, 36, 5, 2, "stun", 8))
up("Cutting Thread", "A razor-thin thread that cuts a target: 3 + 1.2 per skill level damage. 8 MP.", castfx("bolt", 8, 1, 14, 3, 1.2), cost=50)
up("Spatial Maneuvering", "Blink up to 10 blocks forward. 12 MP.", castfx("dash", 12, 3, 10), cost=60)
up("Dimensional Maneuvering", "Blink up to 30 blocks forward. 25 MP.", castfx("dash", 25, 4, 30))
up("Curse", "Curse a target: weakness and wither for 6s. 15 MP.", castfx("bolt", 15, 3, 24, 0, 0, "weakness,wither", 6), cost=50)
up("Jinx", "A heavier curse: weakness, slowness and wither. 30 MP.", castfx("bolt", 30, 4, 28, 0, 0, "weakness,slowness,wither", 8, 0, 1))
for i, n in enumerate(["Undying Body", "Undying Commander", "Undying King"]):
    up(n, f"Your body refuses to die: strong regeneration for 15s. {30 + 20 * i} MP.", castfx("self", 30 + 20 * i, 40, 0, 0, 0, "regeneration,resistance" if i == 2 else "regeneration", 15, 0, i + 1), cost=70 if i == 0 else 0)
up("Iron Defense", "Harden yourself: resistance and absorption for 10s. 15 MP.", castfx("self", 15, 20, 0, 0, 0, "resistance,absorption", 10, 0, 1), cost=45)
for i, (n, r) in enumerate([("Telescopic Sight", 24), ("Clairvoyance", 48), ("Panoptic Vision", 96)]):
    up(n, f"Spot hostile creatures within {r} blocks and make them glow. {5 + 5 * i} MP.", castfx("reveal", 5 + 5 * i, 4, r, 0, 0, "glow", 5), cost=30 if i == 0 else 0)
up("Poison Synthesis", "Brew a potion of poison into your inventory. 15 MP.", castfx("synth", 15, 5, 0, 0, 0, "poison"), cost=40)
up("Medicine Synthesis", "Brew a potion of healing into your inventory. 20 MP.", castfx("synth", 20, 5, 0, 0, 0, "healing"), cost=40)

# ---- Perception ----
up("Appraisal", "Read the name, HP, Offense, Defense and Speed of what you are aiming at (works on players too).", castfx("appraise", 0, 1, 32), cost=10)
for n, r in [("Danger Perception", 24), ("Presence Perception", 24), ("Motion Perception", 20), ("Heat Perception", 20), ("Reaction Perception", 20)]:
    up(n, f"Sense hostile creatures within {r} blocks and make them glow. 5 MP.", castfx("reveal", 5, 4, r, 0, 0, "glow", 5), cost=30)
up("Detection", "Sense every hostile creature within 40 blocks. 8 MP.", castfx("reveal", 8, 4, 40, 0, 0, "glow", 6))
for i, n in enumerate(["Thought Acceleration", "Thought Super-Acceleration"]):
    up(n, f"Your thoughts run fast: skills recharge {[2, 4][i]}% faster per skill level.", {"passive": "cooldown", "passive_power": [2, 4][i]}, cost=40 if i == 0 else 0, train="alive")
up("Parallel Thinking", "Skills recharge 3% faster per skill level.", {"passive": "cooldown", "passive_power": 3}, cost=60, train="alive")
up("Parallel Minds", "Skills recharge 6% faster per skill level.", {"passive": "cooldown", "passive_power": 6}, train="alive")
for n, pw, c in [("Prediction", 1, 40), ("Foresight", 2, 0), ("Future Sight", 3, 0)]:
    up(n, f"Foresee attacks: {pw}% chance per skill level to dodge any hit (max 50%).", {"passive": "dodge", "passive_power": pw}, cost=c, train="alive")
up("Memory", "You learn faster: +3% skill training per skill level.", {"passive": "skill_xp", "passive_power": 3}, cost=40, train="alive")
up("Record", "You learn much faster: +6% skill training per skill level.", {"passive": "skill_xp", "passive_power": 6}, train="alive")
up("MP Lessened Consumption", "Skills cost 4% less MP per skill level.", {"passive": "mp_discount", "passive_power": 4}, cost=40, train="alive")
up("MP Minimized Consumption", "Skills cost 6% less MP per skill level (max 60%).", {"passive": "mp_discount", "passive_power": 6}, train="alive")

# ---- Passives ----
for i, (n, c) in enumerate([("Flight", 100), ("High-Speed Flight", 0)]):
    up(n, f"Fly in survival. Costs {3 if i == 0 else 1} MP per second while airborne.", {"passive": "flight", "passive_power": i + 1}, cost=c, train="alive")
for i, (n, c) in enumerate([("Swimming", 25), ("High-Speed Swimming", 0)]):
    up(n, "Swim much faster in water.", {"passive": "swim", "passive_power": i + 1}, cost=c, train="alive")
up("Camouflage", "Become invisible while sneaking.", {"passive": "camouflage", "passive_power": 1}, cost=40, train="alive")
up("Concealment", "Become invisible while sneaking or standing still.", {"passive": "camouflage", "passive_power": 2}, train="alive")
for n, pw, c in [("Intimidation", 1, 50), ("Tyrant", 1.5, 0), ("Emperor", 2, 0)]:
    up(n, f"Hostile creatures near you are weakened (and slowed from tier 2). Range grows with level.", {"passive": "intimidate", "passive_power": pw}, cost=c, train="alive")
for n, pw, c in [("Swordsmanship", 0.15, 40), ("Sword Mastery", 0.75, 0), ("Sword Hero", 3, 0)]:
    up(n, f"Adds {pw} damage per skill level when you hit with a sword.", {"passive": "sword", "passive_power": pw}, cost=c, train="melee_hit")
for n, pw, c in [("Athletics", 0.15, 30), ("Martial Arts Mastery", 0.75, 0)]:
    up(n, f"Adds {pw} damage per skill level when you fight bare-handed.", {"passive": "unarmed", "passive_power": pw}, cost=c, train="melee_hit")
up("Vampire", "Heal for 1.5% of the damage you deal per skill level.", {"passive": "vampire", "passive_power": 1.5}, cost=60, train="melee_hit")
up("Higher Vampire", "Heal for 4% of the damage you deal per skill level.", {"passive": "vampire", "passive_power": 4}, train="melee_hit")
for n, pw in [("Hit", 0.1), ("Probability Correction", 0.3), ("Probability Super-Correction", 0.8)]:
    up(n, f"Your strikes find the mark: +{pw} damage per skill level on melee hits.", {"hit_damage": pw}, cost=30 if n == "Hit" else 0, train="melee_hit")
for names, fl in [(("Shell", "Hard Armor", "Heavy Armor"), (2, 20, 200)), (("Ore Body", "Steel Body", "Ultra Steel Body"), (2, 20, 200)),
                  (("Dragon Scales", "Imperial Scales", "Divine Scales"), (3, 30, 300))]:
    for i, n in enumerate(names):
        up(n, f"Adds +{fl[i]} Defense per skill level.", cost=30 if i == 0 else 0, train="take_damage", stat="defense", flat=fl[i], growth=fl[i] / 10)

# ---- Ruler / body skills ----
for i, n in enumerate(["Anger", "Rage", "Wrath"]):
    up(n, f"Massively raises Offense, Defense and Speed: +{[10, 100, 1000][i]} each per skill level.", train="melee_hit", stat="physical", flat=[10, 100, 1000][i], growth=[1, 10, 100][i])
for el, cat in [("Fire", "fire"), ("Earth", "earth"), ("Water", "drown"), ("Wind", "impact"), ("Light", "magic"), ("Dark", "magic")]:
    for i, n in enumerate([f"{el} Wyrm", f"{el} Dragon"]):
        up(n, f"Draconic body: absorbs {[5, 10][i]}% of {cat} damage per skill level and adds {[0.3, 1.0][i]} damage per level to your hits.",
           {"resist": [cat], "resist_pct": [5, 10][i], "hit_damage": [0.3, 1.0][i]}, train="melee_hit")

# ============================ WRITE ============================
if os.path.isdir(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)
ORDER = ["_status", "_canon", "name", "description", "tier", "max_level", "stat", "flat_per_level", "growth_per_level",
         "hp_regen_pct", "mp_regen_pct", "cost", "train_on", "train_xp", "learn_on", "learn_amount", "fx", "evolves_to"]
for sid, d in skills.items():
    with open(f"{OUT}/{sid}.json", "w") as f:
        json.dump({k: d[k] for k in ORDER if k in d}, f, indent=2)
        f.write("\n")

func = [s for s in skills.values() if s["_status"] == "functional"]
lines = ["# Canon skill list", "",
         f"{len(skills)} skills from the wiki's skill list. {len(func)} do something in the mod; the rest are listed",
         "(and grantable with `/isekai grantskill <id> <level>`) but their effects aren't built yet.", "",
         "Skipped on purpose: Platformer Movement and Food Poisoning Resistance (marked non-canon on the wiki).", "",
         "Legend: ✅ works now, 📋 catalog only.", ""]
for cat, ids in cats.items():
    lines.append(f"## {cat}")
    for sid in ids:
        d = skills[sid]
        lines.append(f"- {'✅' if d['_status']=='functional' else '📋'} {d['name']} (T{d['tier']}) `{sid}`")
    lines.append("")
open("SKILLS.md", "w").write("\n".join(lines))
print(f"{len(skills)} skills written, {len(func)} functional")
for cat, ids in cats.items():
    print(f"  {cat:32}{len(ids):>4}  functional {sum(1 for i in ids if skills[i]['_status']=='functional')}")
