# Isekai RPG - a "So I'm a Spider, So What?" mod (NeoForge 1.21.1)

This folder is a complete, ready-to-build mod project. Nothing to copy or merge.

## Get the .jar (pick one)

**A. On your PC (Windows)**
1. Install JDK 21 (Temurin): https://adoptium.net
2. Unzip this folder, double-click `build.bat`
3. Wait a few minutes the first time. Your jar is in `build\libs\isekai-0.3.0.jar`
   (use the one WITHOUT `-sources` in its name)

Mac/Linux: run `./build.sh` instead.

**B. No install: let GitHub build it**
1. Make a free GitHub repo and upload this whole folder (keep the `.github` folder)
2. Open the repo's **Actions** tab, run **Build jar**, then download `isekai-mod-jar` from the finished run

## Use it
- CurseForge app: create a custom profile, Minecraft 1.21.1 + NeoForge, open its folder, drop the jar in `mods`
- In game: press **K** for the status window. Pick a species on first join.
- `./gradlew runClient` launches the game straight from the source if you want to test quickly

## What's in it
- Species picker and evolutions: Taratect line (Small Lesser Taratect up to Queen), Goblin line (to Ogre), Human
- Stats, HP/MP, skill points, and a Skills screen
- 404 canon skills from the wiki (see `SKILLS.md`): 241 do something now, the rest are listed but inert
- Casting: **R** casts the selected skill, **V / B** switch skill (rebindable). Bolts hit what you aim at.
- Skills are learned by doing the action (hit things, take hits, sprint...) or bought with skill points

## Editing content (no Java needed)
- Species: `src/main/resources/data/isekai/species/*.json`
- Skills: `src/main/resources/data/isekai/skills/*.json`, regenerate all with `python tools/gen_skills.py`
- In game, `/reload` picks up data changes
- Every file has `_canon` / `_note` fields saying what is verified from the wiki and what is an ESTIMATE

## Debug commands (op)
`/isekai addxp 500` `/isekai addsp 100` `/isekai grantskill skanda 5` `/isekai setspecies queen_taratect` `/isekai reset`

## Honest status
The code has not been compiled or played by me. I could only check it for syntax errors and for names that
don't match my own classes. If the build fails, send me the error text and I'll fix it.

## Textures
`tools/texture_tool.py` makes item icons from game-icons.net or other packs (`pip install -r tools/requirements.txt`).
