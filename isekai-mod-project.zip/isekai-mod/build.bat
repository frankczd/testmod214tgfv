@echo off
call gradlew.bat build
echo.
echo Done. Your mod jar is in build\libs\  (use the one WITHOUT -sources)
pause
